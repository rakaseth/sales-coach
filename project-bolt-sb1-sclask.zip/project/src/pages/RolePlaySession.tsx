import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Timer, Settings } from 'lucide-react';
import { ChatMessage } from '../components/ChatMessage';
import { AudioControls } from '../components/AudioControls';
import { WebSocketClient } from '../utils/websocket';
import { Message, AudioState } from '../types';

const RolePlaySession = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { topic, company } = location.state || {};
  
  const [messages, setMessages] = useState<Message[]>([]);
  const [audioState, setAudioState] = useState<AudioState>({
    isConnected: false,
    isCallActive: false,
    error: null,
    timeRemaining: 300, // 5 minutes in seconds
  });

  const [wsClient, setWsClient] = useState<WebSocketClient | null>(null);

  useEffect(() => {
    if (!topic || !company) {
      navigate('/role-play/setup');
      return;
    }

    const client = new WebSocketClient(
      (message) => {
        setMessages((prev) => [...prev, { ...message, timestamp: Date.now() }]);
      },
      (connected) => {
        setAudioState((prev) => ({ ...prev, isConnected: connected }));
      },
      (error) => {
        setAudioState((prev) => ({ ...prev, error }));
      }
    );

    setWsClient(client);

    return () => {
      client.disconnect();
    };
  }, [topic, company, navigate]);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (audioState.isCallActive && audioState.timeRemaining > 0) {
      timer = setInterval(() => {
        setAudioState((prev) => ({
          ...prev,
          timeRemaining: prev.timeRemaining - 1,
        }));
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [audioState.isCallActive, audioState.timeRemaining]);

  const handleStartCall = async () => {
    try {
      const response = await fetch('http://localhost:8000/api/start-call', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic, company }),
      });
      
      if (response.ok) {
        const { callId } = await response.json();
        wsClient?.connect({
          apiKey: import.meta.env.VITE_RETELL_API_KEY,
          callId,
          baseUrl: 'http://localhost:8000',
        });
        setAudioState((prev) => ({ ...prev, isCallActive: true }));
      }
    } catch (error) {
      console.error('Error starting call:', error);
      setAudioState((prev) => ({ 
        ...prev, 
        error: 'Failed to start call. Please try again.' 
      }));
    }
  };

  const handleEndCall = () => {
    wsClient?.disconnect();
    setAudioState((prev) => ({ ...prev, isCallActive: false }));
    navigate('/role-play/feedback', { 
      state: { messages, topic, company } 
    });
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="max-w-7xl mx-auto p-4"
      >
        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm p-4 mb-4 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-semibold text-gray-800">
              {topic} - {company}
            </h1>
            <p className="text-sm text-gray-500">Role-Play Session</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-full">
              <Timer className="w-4 h-4 text-gray-600" />
              <span className="font-medium">
                {formatTime(audioState.timeRemaining)}
              </span>
            </div>
            <button 
              onClick={() => navigate('/role-play/setup')}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <Settings className="w-5 h-5 text-gray-600" />
            </button>
          </div>
        </div>

        {/* Chat Container */}
        <div className="bg-white rounded-lg shadow-sm min-h-[600px] flex flex-col">
          <div className="flex-1 p-4 space-y-4 overflow-y-auto">
            {messages.map((message, index) => (
              <ChatMessage key={index} message={message} />
            ))}
            {messages.length === 0 && !audioState.isCallActive && (
              <div className="h-full flex items-center justify-center text-gray-500">
                Click "Start Call" to begin the role-play session
              </div>
            )}
          </div>

          {/* Audio Controls */}
          <AudioControls
            audioState={audioState}
            onStartCall={handleStartCall}
            onEndCall={handleEndCall}
          />
        </div>

        {/* Error Message */}
        {audioState.error && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg text-red-600"
          >
            {audioState.error}
          </motion.div>
        )}
      </motion.div>
    </div>
  );
};

export default RolePlaySession;