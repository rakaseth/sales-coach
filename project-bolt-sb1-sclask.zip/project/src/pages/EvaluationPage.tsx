import React from 'react';
import { motion } from 'framer-motion';

const EvaluationPage = () => {
  return (
    <div className="min-h-screen p-8">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="max-w-4xl mx-auto text-center"
      >
        <h1 className="text-3xl font-bold text-gray-800 mb-4">Conversation Evaluation</h1>
        <p className="text-gray-600">Coming soon...</p>
      </motion.div>
    </div>
  );
};

export default EvaluationPage;