import React from 'react';
import { Mic, MicOff, Phone, PhoneOff } from 'lucide-react';
import { AudioState } from '../types';

interface AudioControlsProps {
  audioState: AudioState;
  onStartCall: () => void;
  onEndCall: () => void;
}

export const AudioControls: React.FC<AudioControlsProps> = ({
  audioState,
  onStartCall,
  onEndCall,
}) => {
  return (
    <div className="flex items-center justify-center gap-4 p-4 bg-white border-t border-gray-200">
      <button
        onClick={audioState.isCallActive ? onEndCall : onStartCall}
        className={`flex items-center gap-2 px-6 py-3 rounded-full font-medium transition-colors ${
          audioState.isCallActive
            ? 'bg-red-500 hover:bg-red-600 text-white'
            : 'bg-blue-500 hover:bg-blue-600 text-white'
        }`}
      >
        {audioState.isCallActive ? (
          <>
            <PhoneOff size={20} />
            End Call
          </>
        ) : (
          <>
            <Phone size={20} />
            Start Call
          </>
        )}
      </button>
      <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-gray-100">
        {audioState.isConnected ? (
          <>
            <Mic size={18} className="text-green-500" />
            <span className="text-sm text-gray-600">Connected</span>
          </>
        ) : (
          <>
            <MicOff size={18} className="text-red-500" />
            <span className="text-sm text-gray-600">Disconnected</span>
          </>
        )}
      </div>
    </div>
  );
};