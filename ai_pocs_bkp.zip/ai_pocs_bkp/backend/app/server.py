import json
import os
import asyncio
from langchain.prompts import PromptTemplate
from dotenv import load_dotenv
from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from langchain_openai import AzureChatOpenAI
from concurrent.futures import TimeoutError as ConnectionTimeoutError
from retell import Retell

import httpx
from .custom_types import (
    ConfigResponse,
    ResponseRequiredRequest,
)
from .llm import LlmClient  # or use .llm_with_func_calling
llm=AzureChatOpenAI()
load_dotenv(override=True)
app = FastAPI()
retell = Retell(api_key=os.environ["RETELL_API_KEY"])

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Adjust this to allow specific origins as needed
    allow_credentials=True,
    allow_methods=["*"],  # Allow all methods (GET, POST, etc.)
    allow_headers=["*"],  # Allow all headers
)

class RolePlayRequest(BaseModel):
    topic: str
    srccompany: str
    dstcompany: str
    tone: str
    coachrole: str
    userrole: str
    scenario: str = None


class WebCallRequest(BaseModel):
    agent_id: str
    metadata: dict = None
    retell_llm_dynamic_variables: dict = None
    tone: str = "formal"
    scenario: str = None
    srccompany: str = None
    dstcompany: str = None
    coachrole: str = None
    userrole: str = None
    coachType: str = None



# Define the route for /api/setup-roleplay
@app.post("/api/generateScenario")
async def generate_scenario(request: RolePlayRequest):
    topic = request.topic
    srccompany = request.srccompany
    dstcompany= request.dstcompany
    tone = request.tone
    coachrole = request.coachrole
    userrole = request.userrole
    prompttemplate = PromptTemplate(
        input_variables=["topic","srccompany","dstcompany","coachrole","userrole"],
        template=(
        f"You're a meticulous analyst and researcher with ability to find out best and complexscenarios which can lead to healthy discussion between customer and sales agent.\n"
        f" user wants to play role of {userrole} and AI should play role as {coachrole}"
        f"if topic is provided then use that {topic} to generate the scenario.\n"
        f"find only one of the most relevent scenario which can lead to a productive discussion.\n"
        f"keep in mind that the scenario should be unique and should not be same always.\n"
        f"keep yourself to only provide the scenario and nothing else.\n"
        f"don't create a role play conversation, just provide the scenario.\n"
        f"""make scenario with below details while adding details product we want to sales is from {srccompany} and selling it to {dstcompany} to {coachrole} by {userrole}:
        - heading: with detail of scenario as per the {topic}
        - instruction: provide step by instruction to user about how the call should go:
          for example: if price negotiation is there as scenario:
            1)present your quote and ask customer to confirm terms
            2)listen to customer and handles the objections.
            3)reach to an agreement
        above example can change as per {topic} and scenario.
        """
        )
    )
    prompt = prompttemplate.format(topic=topic,srccompany=srccompany,dstcompany=dstcompany,coachrole=coachrole, userrole=userrole)
    # Generate the scenario using the LLM
    scenario =await llm.ainvoke([{"role": "user", "content": prompt}])
      
    response_data = {
        "message": "Roleplay setup successful",
        "topic": topic,
        "srccompany": srccompany,
        "dstcompany": dstcompany,
        "tone": tone,
        "scenario": f"{scenario.content}"
    }

    return response_data

@app.post("/feedback")
async def generate_feedback(request: RolePlayRequest):
    tone = request.tone
    scenario=request.scenario
    with open("/Users/raushankumar/Downloads/ai_pocs/src/conversation_history.txt", "r") as file:
        conversation_history = file.read()
    
    prompttemplate = PromptTemplate(
    input_variables=["scenario","conversation_history"],
    template=(
        """You are an expert in evaluating the conversations.evaluate conversation only for user not for assistant:
         conversation_history:\n{conversation_history}\n
         first go through {scenario} and check if user has convered all the points.If not provie it in feedback.
        Also evaluate the response in below terms:
            1)Scaffolding--Building upon your story over time and connecting each step of the journey
            2)Story--Your ability to both tell a compelling story (NOT SHOW FEATURES) and weave use cases and examples into the presentation
            3)Presentation--Your presence, the language, pace, filler words, volume, enthusiasm
            4)Validation--Verifying and connecting the value of what we show to the audience’s business case. Not asking “does that make sense” but rather “Can you see how XYZ enables you to scale onboarding for your global team”.
            5)Big Why--Everyone has a purpose and we want to make sure that comes through. Not just company specific big why but the clients. Connect Degreed to their company why, personal career, or team purpose.
        summarize your evaluation of the opportunity based on the MEDDPICC components. What are the strengths and weaknesses of this opportunity? What actions should be taken next to improve the chances of closing the deal?
        Also,Evaluate the response based on criteria like Deal summary,Overall Impression,What went well, Growth oppurchunity.\n
        provide good and room to improve details.
        try to keep it in 300 words.
         """
        )
    )

    prompt = prompttemplate.format(scenario=scenario,conversation_history=conversation_history)
    # Generate the scenario using the LLM
    feedback = await llm.ainvoke([{"role": "user", "content": prompt}])
    print(f"feedback is {feedback.content}")
    response_data={
        "feedback": feedback.content
    }
    return response_data

# Declare payload variable at the module level
payload = {}

@app.post("/create-web-call")
async def create_web_call(request_data: WebCallRequest):
    global payload  # Declare payload as global to modify it
    print("request_data",request_data)
    payload = {'agent_id': request_data.agent_id,"coachType":request_data.coachType, "tone": request_data.tone, "srccompany": request_data.srccompany,"dstcompany": request_data.dstcompany,"coachrole": request_data.coachrole,"userrole": request_data.userrole, "scenario": request_data.scenario}

    # Conditionally add optional fields if they are provided
    if request_data.metadata:
        payload['metadata'] = request_data.metadata
    if request_data.retell_llm_dynamic_variables:
        payload['retell_llm_dynamic_variables'] = request_data.retell_llm_dynamic_variables

    headers = {
        'Authorization': 'Bearer 6d4f093a-ab63-4df7-bfd3-7de0ed8cf512',  # Replace with your actual Bearer token
        'Content-Type': 'application/json',
    }

    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                'https://api.retellai.com/v2/create-web-call',
                json=payload,
                headers=headers
            )
            response.raise_for_status()  # Raise an exception for HTTP errors
        print("response.json()", response.json())
        return response.json()

    except httpx.HTTPStatusError as error:
        print('Error creating web call:', error.response.json() if error.response else error)
        raise HTTPException(status_code=500, detail="Failed to create web call")

# Handle webhook from Retell server. This is used to receive events from Retell server.
# Including call_started, call_ended, call_analyzed

@app.post("/create-coaching-call")
async def create_web_call(request_data: WebCallRequest):
    global payload  # Declare payload as global to modify it
    print("request_data",request_data)
    payload = {'agent_id': request_data.agent_id, "coachType": request_data.coachType}
    # Conditionally add optional fields if they are provided
    if request_data.metadata:
        payload['metadata'] = request_data.metadata
    if request_data.retell_llm_dynamic_variables:
        payload['retell_llm_dynamic_variables'] = request_data.retell_llm_dynamic_variables

    headers = {
        'Authorization': 'Bearer 6d4f093a-ab63-4df7-bfd3-7de0ed8cf512',  # Replace with your actual Bearer token
        'Content-Type': 'application/json',
    }

    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                'https://api.retellai.com/v2/create-web-call',
                json=payload,
                headers=headers
            )
            response.raise_for_status()  # Raise an exception for HTTP errors
        print("response.json()", response.json())
        return response.json()

    except httpx.HTTPStatusError as error:
        print('Error creating web call:', error.response.json() if error.response else error)
        raise HTTPException(status_code=500, detail="Failed to create web call")

# Handle webhook from Retell server. This is used to receive events from Retell server.
# Including call_started, call_ended, call_analyzed

@app.post("/webhook")
async def handle_webhook(request: Request):
    try:
        post_data = await request.json()
        valid_signature = retell.verify(
            json.dumps(post_data, separators=(",", ":"), ensure_ascii=False),
            api_key=str(os.environ["RETELL_API_KEY"]),
            signature=str(request.headers.get("X-Retell-Signature")),
        )
        if not valid_signature:
            print(
                "Received Unauthorized",
                post_data["event"],
                post_data["data"]["call_id"],
            )
            return JSONResponse(status_code=401, content={"message": "Unauthorized"})
        if post_data["event"] == "call_started":
            print("Call started event", post_data["data"]["call_id"])
        elif post_data["event"] == "call_ended":
            print("Call ended event", post_data["data"]["call_id"])
        elif post_data["event"] == "call_analyzed":
            print("Call analyzed event", post_data["data"]["call_id"])
        else:
            print("Unknown event", post_data["event"])
        return JSONResponse(status_code=200, content={"received": True})
    except Exception as err:
        print(f"Error in webhook: {err}")
        return JSONResponse(
            status_code=500, content={"message": "Internal Server Error"}
        )

# Start a websocket server to exchange text input and output with Retell server. Retell server
# will send over transcriptions and other information. This server here will be responsible for
# generating responses with LLM and send back to Retell server.
@app.websocket("/llm-websocket/{call_id}")
async def websocket_handler(websocket: WebSocket, call_id: str):
    global payload
    try:
        await websocket.accept()
        print("call_id", call_id)
        llm_client = LlmClient(payload)

        # Send optional config to Retell server
        config = ConfigResponse(
            response_type="config",
            config={
                "auto_reconnect": True,
                "call_details": True,
            },
            response_id=1,
        )
        await websocket.send_json(config.__dict__)

        # Send first message to signal ready of server
        response_id = 0
        first_event = llm_client.draft_begin_message(payload.get("scenario"))
        await websocket.send_json(first_event.__dict__)

        async def handle_message(request_json):
            nonlocal response_id

            # There are 5 types of interaction_type: call_details, pingpong, update_only, response_required, and reminder_required.
            # Not all of them need to be handled, only response_required and reminder_required.
            if request_json["interaction_type"] == "call_details":
                print(json.dumps(request_json, indent=2))
                return
            if request_json["interaction_type"] == "ping_pong":
                await websocket.send_json(
                    {
                        "response_type": "ping_pong",
                        "timestamp": request_json["timestamp"],
                    }
                )
                return
            if request_json["interaction_type"] == "update_only":
                return
            if (
                request_json["interaction_type"] == "response_required"
                or request_json["interaction_type"] == "reminder_required"
            ):
                response_id = request_json["response_id"]
                request = ResponseRequiredRequest(
                    interaction_type=request_json["interaction_type"],
                    response_id=response_id,
                    transcript=request_json["transcript"],
                )
                print(
                    f"""Received interaction_type={request_json['interaction_type']}, response_id={response_id}, last_transcript={request_json['transcript'][-1]['content']}"""
                )

                async for event in llm_client.draft_response(request):
                    await websocket.send_json(event.__dict__)
                    if request.response_id < response_id:
                        break  # new response needed, abandon this one

        async for data in websocket.iter_json():
            asyncio.create_task(handle_message(data))

    except WebSocketDisconnect:
        print(f"LLM WebSocket disconnected for {call_id}")
    except ConnectionTimeoutError as e:
        print("Connection timeout error for {call_id}")
    except Exception as e:
        print(f"Error in LLM WebSocket: {e} for {call_id}")
        await websocket.close(1011, "Server error")
    finally:
        print(f"LLM WebSocket connection closed for {call_id}")


class EvaluateCall(BaseModel):
   transcript: str
   whomToEvaluate: str

@app.post("/evaluateCall")
async def eavluat_and_generate_feedback(request: EvaluateCall):
    transcript = request.transcript
    whomToEvaluate = request.whomToEvaluate
    print(f" transcript\n\n{transcript}")
    
    prompttemplate = PromptTemplate(
    input_variables=["conversation_history","whomToEvaluate"],
    template=(
        """You are an expert in evaluating the conversations.evaluate conversation only for {whomToEvaluate}:
         conversation_history:\n{conversation_history}\n
        evaluate the conversation in below terms and score below 5 points percentage in achieving goal:
            1)Scaffolding--Building upon your story over time and connecting each step of the journey
            2)Story--Your ability to both tell a compelling story (NOT SHOW FEATURES) and weave use cases and examples into the presentation
            3)Presentation--Your presence, the language, pace, filler words, volume, enthusiasm
            4)Validation--Verifying and connecting the value of what we show to the audience’s business case. Not asking “does that make sense” but rather “Can you see how XYZ enables you to scale onboarding for your global team”.
            5)Big Why--Everyone has a purpose and we want to make sure that comes through. Not just company specific big why but the clients. Connect Degreed to their company why, personal career, or team purpose.
        summarize your evaluation of the opportunity based on the MEDDPICC components. What are the strengths and weaknesses of this opportunity? What actions should be taken next to improve the chances of closing the deal?
        Also,Evaluate the response based on criteria like Deal summary,Overall Impression,What went well, Growth oppurchunity.\n
        create a proper structure of response to show on react pagethere should be 5 keys feedback,MEDDPICC Summary,Next Steps,Room for improvement,score.
        try to keep it in 350 words.
         """
        )
    )

    prompt = prompttemplate.format(conversation_history=transcript,whomToEvaluate=whomToEvaluate)
    # Generate the scenario using the LLM
    feedback = await llm.ainvoke([{"role": "user", "content": prompt}])
    response_data={
        "feedback": feedback.content
    }
    print("response_data",response_data)
    return response_data


