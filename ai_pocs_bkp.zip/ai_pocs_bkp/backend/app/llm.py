from openai import AsyncAzureOpenAI
import os
from dotenv import load_dotenv
load_dotenv()

import os
from typing import List
from .custom_types import (
    ResponseRequiredRequest,
    ResponseResponse,
    Utterance,
)



class LlmClient:
    def __init__(self, session_data):
        self.client = AsyncAzureOpenAI(
            api_key=str(os.getenv("AZURE_GPT_4O_API_KEY")),
            api_version=str(os.getenv("AZURE_GPT_4O_API_VERSION")),
            azure_endpoint=str(os.getenv("AZURE_GPT_4O_BASE_URL"))
            )
        print("session_data",session_data)
        self.session_data = session_data

    def draft_begin_message(self,scenario):
        response = ResponseResponse(
            response_id=0,
            content=f"Hi,I am ray. How are you today?",
            content_complete=True,
            end_call=False,
        )
        return response

    def convert_transcript_to_openai_messages(self, transcript: List[Utterance]):
        messages = []
        for utterance in transcript:
            if utterance.role == "agent":
                messages.append({"role": "assistant", "content": utterance.content})
            else:
                messages.append({"role": "user", "content": utterance.content})
        return messages

    def prepare_prompt(self, request: ResponseRequiredRequest):
        x = f"""
        ##Objective\nYou are a voice AI agent engaging in a human-like voice conversation with the user. You will respond based on your given instruction and the provided transcript and be as human-like as possible\n\n##overall Gaurdrails \n - This platform is designed for constructive, educational, and professional discussions. Conversations involving harmful, abusive, or inappropriate topics (e.g., violence, abuse, self-harm, exploitation, or offensive content) are not allowed. Please maintain a respectful and appropriate tone.If you're experiencing thoughts of self-harm or suicide, please understand that this platform cannot provide the help you need. I encourage you to seek professional assistance or contact a crisis hotline in your region immediately. You are not alone, and help is available.Discussions or content related to child exploitation, abuse, or harm are strictly prohibited. If you or someone you know is in danger, please contact the appropriate authorities or child protection services immediately. This platform does not tolerate any form of harm towards children.This platform is a safe and respectful space. Use of abusive, discriminatory, or harassing language is not tolerated. Please remain courteous and constructive in your communication. Continued violations may result in being restricted from further interactions.This platform does not support or tolerate discussions promoting illegal activities, violence, or harm of any kind. If you have questions, please focus on constructive and lawful topics.
        ## Style Guardrails\n- [Be concise] Keep your response succinct, short, and get to the point quickly. Address one question or action item at a time. Don\'t pack everything you want to say into one utterance.\n- [Do not repeat] Don\'t repeat what\'s in the transcript. Rephrase if you have to reiterate a point. Use varied sentence structures and vocabulary to ensure each response is unique and personalized.\n-  [Reply ]: reply only to the context mentioned in scenario if question is not around it tell user that you can't help here.\n- Response Guideline\n- [Overcome ASR errors] This is a real-time transcript, expect there to be errors. If you can guess what the user is trying to say,  then guess and respond. When you must ask for clarification, pretend that you heard the voice and be colloquial (use phrases like "didn\'t catch that", "some noise", "pardon", "you\'re coming through choppy", "static in your speech", "voice is cutting in and out"). \n- [Always stick to your role] Think about what your role can and cannot do. If your role cannot do something, try to steer the conversation back to the goal of the conversation and to your role. Don\'t repeat yourself in doing this. You should still be creative, human-like, and lively.\n- [Create smooth conversation] Your response should both fit your role and fit \n\n## Role\n'
        """
        #begin_sentence = ""
        agent_prompt=""
        if "RolePlay" in self.session_data.get("coachType") :
                agent_prompt = f"""As a professional coach skilled in role-play, your responsibilities are centered on embodying the designated role which is {self.session_data['coachrole']} who is working in {self.session_data['userrole']}.
                actor/user: You have to role play with actor who is performing as {self.session_data['userrole']} and working at {self.session_data['srccompany']}
                scenario: {self.session_data['scenario']} \n is only for your understanding.
                keep the tone {self.session_data['tone']}  of conversation in mind.
                Act as a role-play agent who is firm, inquisitive, and difficult to convince. Engage the user in deeper discussion, challenging their points and asking clarifying questions. 
                Maintain a stance that doesn’t easily agree, encouraging the user to thoroughly explain and support their perspective before considering alignment.
                actor is performing role of  {self.session_data['userrole']}.Wait for actor to start conversation on {self.session_data['scenario']}.if actor has not started conversation on {{self.session_data['scenario']}}.Don't start playing role of {self.session_data['userrole']}.
                Strictly,the instruction mentioned in  {self.session_data['scenario']} is not for assitant but for user role. wait for user to start conversation about topics mentioned in {self.session_data['scenario']} and you need to behave as buyer or customer.
                Don't create the whole role-play scenario at once wait for the conversation.
                """
        if "SalesCoach" in self.session_data.get("coachType"):
               agent_prompt=f"""You are an experienced and professional sales coach. Your role is to mentor and guide the user in mastering key sales skills, techniques, and strategies. 
               Your responsibilities include:
                    - Sharing best practices, tips, and frameworks to improve sales performance.
                    - Encouraging the user to think critically and reflect on their approach, highlighting areas of improvement.
                    - Maintaining a constructive and supportive tone to motivate the user.
               ### Guidelines:
                1. **Tone**: Be professional, empathetic, and motivational. Balance positive reinforcement with constructive criticism.
                2. **Sales Frameworks**: Reference industry-standard sales techniques where applicable (e.g., SPIN Selling, MEDDIC, BANT, etc.).
               ### Instructions for Sales Coaching Sessions:
                - Ask clarifying questions to understand the user’s sales context (e.g., industry, product, audience).
                - If the user provides a sales pitch or script, evaluate it based on clarity, persuasion, relevance, and emotional appeal.
                - Simulate real-life sales conversations by introducing objections or challenges and assess the user’s ability to handle them effectively.
                - Encourage self-reflection by asking, "How do you think this could be improved?" before providing your input.              
               """
        prompt = [
            {
                "role": "system",
                "content": x
                + agent_prompt,
            }
        ]
        transcript_messages = self.convert_transcript_to_openai_messages(
            request.transcript
        )
        #print(f"\ntranscript_messages\n\n{transcript_messages}")
        for message in transcript_messages:
            prompt.append(message)

        if request.interaction_type == "reminder_required":
            prompt.append(
                {
                    "role": "user",
                    "content": "(Now the user has not responded in a while, you would say:)",
                }
            )
        #print(f"prompt : {prompt} \n\n")
        return prompt,transcript_messages
    

    async def draft_response(self, request: ResponseRequiredRequest):
        prompt,transcript = self.prepare_prompt(request)

        ## relevant_data =  self.function(prompt[-1])
        # prompt[]
        stream = await self.client.chat.completions.create(
            model=os.getenv("AZURE_GPT_4O_DEPLOYMENT_NAME"),  # Or use a 3.5 model for speed
            messages=prompt,
            stream=True,
        )
        async for chunk in stream:
            if chunk.choices and chunk.choices[0].delta and chunk.choices[0].delta.content is not None:
                response = ResponseResponse(
                    response_id=request.response_id,
                    content=chunk.choices[0].delta.content,
                    content_complete=False,
                    end_call=False,
                )
                yield response

        # Send final response with "content_complete" set to True to signal completion
        with open("/Users/raushankumar/Downloads/ai_pocs/src/conversation_history.txt","w") as file:
            for conv in transcript:
                for key,value in conv.items():
                    file.write(f"{key}:{value}")
        response = ResponseResponse(
            response_id=request.response_id,
            content="",
            content_complete=True,
            end_call=False,
        )
        yield response
