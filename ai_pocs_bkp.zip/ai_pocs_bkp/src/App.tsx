import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import LandingPage from './pages/LandingPage';
import RolePlaySetup from './pages/RolePlaySetup';
import RolePlaySession from './pages/RolePlaySession';
import FeedbackPage from './pages/FeedbackPage';
import CoachingSession from './pages/CoachingSession';
import EvaluationPage from './pages/EvaluationPage';

function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/role-play/setup" element={<RolePlaySetup />} />
          <Route path="/role-play/session" element={<RolePlaySession />} />
          <Route path="/role-play/feedback" element={<FeedbackPage />} />
          <Route path="/coaching" element={<CoachingSession />} />
          <Route path="/evaluate" element={<EvaluationPage />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;