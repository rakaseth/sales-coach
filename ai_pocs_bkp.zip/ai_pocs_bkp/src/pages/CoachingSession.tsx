import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Settings } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';
import { RetellWebClient } from 'retell-client-js-sdk';
import { AudioControls } from '../components/AudioControls';
import { AudioState } from '../types';

const agentId = "agent_cbd0814ca213c998f7be8fe3ec";
const retellWebClient = new RetellWebClient();

const CoachingSession = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { topic, skillLevel, focusArea } = location.state || {};

  const [audioState, setAudioState] = useState<AudioState>({
    isConnected: false,
    isCallActive: false,
    error: null,
    timeRemaining: 300
  });
  const [isCalling, setIsCalling] = useState(false);

  useEffect(() => {
    retellWebClient.on("call_started", () => {
      setIsCalling(true);
      setAudioState(prev => ({ ...prev, isConnected: true }));
    });

    retellWebClient.on("call_ended", () => {
      setIsCalling(false);
      setAudioState(prev => ({ ...prev, isCallActive: false, isConnected: false }));
    });

    retellWebClient.on("error", (error) => {
      console.error("Error:", error);
      retellWebClient.stopCall();
      setIsCalling(false);
      setAudioState(prev => ({ ...prev, error: error.message }));
    });

    return () => {
      retellWebClient.removeAllListeners();
    };
  }, []);

  const toggleConversation = async () => {
    if (isCalling) {
      retellWebClient.stopCall();
    } else {
      try {
        const response = await fetch("http://localhost:8080/create-web-call", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ 
            agent_id: agentId, 
            coachType: 'SalesCoach'
          })
        });

        if (response.ok) {
          const { access_token } = await response.json();
          await retellWebClient.startCall({ accessToken: access_token });
          setAudioState(prev => ({ ...prev, isCallActive: true }));
        } else {
          throw new Error(`Call start failed with status ${response.status}`);
        }
      } catch (error) {
        console.error("Error starting call:", error);
        setAudioState(prev => ({ ...prev, error: 'Failed to start call' }));
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="max-w-4xl mx-auto p-6"
      >
        <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-gray-800">Sales Coaching Session</h1>
            <button 
              onClick={() => navigate('/coaching/setup')} 
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <Settings className="w-6 h-6 text-gray-600" />
            </button>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="mb-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-2">Instructions</h2>
            <p className="text-gray-600">
              Speak clearly into your microphone. Your AI sales coach will guide you through 
              the session. Click "Start Call" when you're ready to begin.
            </p>
          </div>

          <AudioControls
            audioState={audioState}
            onStartCall={toggleConversation}
            onEndCall={toggleConversation}
          />

          {audioState.error && (
            <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-red-600">{audioState.error}</p>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};

export default CoachingSession;