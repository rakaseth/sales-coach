import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Settings } from 'lucide-react';
import { ChatMessage } from '../components/ChatMessage';
import { AudioControls } from '../components/AudioControls';
import { Message, AudioState } from '../types';
import { RetellWebClient } from 'retell-client-js-sdk';

const agentId = "agent_cbd0814ca213c998f7be8fe3ec";
const retellWebClient = new RetellWebClient();

const RolePlaySession = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { topic, srccompany, dstcompany, coachrole, userrole, tone, scenario } = location.state || {};

  const [messages, setMessages] = useState<Message[]>([]);
  const [audioState, setAudioState] = useState<AudioState>({
    isConnected: false,
    isCallActive: false,
    error: null,
    timeRemaining: 300
  });
  const [isCalling, setIsCalling] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [isLoadingFeedback, setIsLoadingFeedback] = useState(false);
  const [isFeedbackModalOpen, setIsFeedbackModalOpen] = useState(false);

  // Redirect to setup if essential data is missing
  if (!topic || !srccompany || !dstcompany) {
    navigate('/role-play/setup');
  }

  useEffect(() => {
    // Event listeners for call actions
    retellWebClient.on("call_started", () => setIsCalling(true));
    retellWebClient.on("call_ended", async () => {
      setIsCalling(false);
      setAudioState((prev) => ({ ...prev, isCallActive: false }));
      await fetchFeedback();
      console.log("feedback -->",feedback) // Fetch feedback after call ends
    });
    retellWebClient.on("error", (error) => {
      console.error("Error:", error);
      retellWebClient.stopCall();
      setIsCalling(false);
    });

    return () => {
      // Clean up event listeners
      retellWebClient.removeAllListeners();
    };
  }, []);

  const fetchFeedback = async () => {
    setIsLoadingFeedback(true);
    try {
      const response = await fetch("http://localhost:8080/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic, srccompany, dstcompany, coachrole, userrole, tone, scenario })
      });

      if (!response.ok) {
        throw new Error(`Feedback fetch failed with status ${response.status}`);
      }

      const { feedback } = await response.json();
      setFeedback(feedback);
      console.log("feedback----,,,..",feedback)
      setIsFeedbackModalOpen(true); // Open the modal with the feedback
    } catch (error) {
      console.error("Error fetching feedback:", error);
    } finally {
      setIsLoadingFeedback(false);
    }
  };

  const toggleConversation = async () => {
    if (isCalling) {
      retellWebClient.stopCall();
    } else {
      try {
        const response = await fetch("http://localhost:8080/create-web-call", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ agent_id: agentId,coachType: 'RolePlay', tone, srccompany, dstcompany, coachrole, userrole, scenario })
        });

        if (response.ok) {
          const { access_token } = await response.json();
          await retellWebClient.startCall({ accessToken: access_token });
          setAudioState((prev) => ({ ...prev, isCallActive: true }));
        } else {
          throw new Error(`Call start failed with status ${response.status}`);
        }
      } catch (error) {
        console.error("Error starting call:", error);
      }
    }
  };

  const closeModal = () => setIsFeedbackModalOpen(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-7xl mx-auto p-4">
        <div className="bg-white rounded-lg shadow-sm p-4 mb-4 flex items-center justify-between">
          <h1 className="text-xl font-semibold text-gray-800">
            {topic} - sales product from {srccompany} pitching to {dstcompany} in {tone} tone. You are {userrole}.
          </h1>
          <button onClick={() => navigate('/role-play/setup')} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
            <Settings className="w-6 h-6 text-gray-600" />
          </button>
        </div>

        <div className="mb-4">
          <textarea
            value={scenario}
            readOnly
            rows={8}
            className="w-full p-4 bg-gray-100 rounded-lg border border-gray-300"
          />
        </div>

        <div className="bg-white rounded-lg shadow-sm min-h-[300px] flex flex-col">
          <div className="flex-1 p-4 space-y-4 overflow-y-auto">
            {messages.length > 0 ? (
              messages.map((message, index) => <ChatMessage key={index} message={message} />)
            ) : (
              <p className="text-gray-500"></p>
            )}
          </div>

          <AudioControls
            audioState={audioState}
            onStartCall={toggleConversation}
            onEndCall={toggleConversation}
          />
        </div>

        {isFeedbackModalOpen && feedback && (
        <div className="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
          <div className="bg-white rounded-lg p-6 w-11/12 md:w-3/4 lg:w-2/3 xl:w-1/2 max-h-[90vh] overflow-y-auto"> {/* Adjust modal width and height */}
            <h2 className="text-lg font-semibold text-blue-800 mb-4">Feedback</h2>
            <div className="text-blue-600 whitespace-pre-wrap text-sm">
              {/* Formatting Feedback */}
              {feedback.split('\n').map((line, index) => {
                if (line.startsWith('#')) {
                  // Render headers (##anytext## -> as headers)
                  return (
                    <h3 key={index} className="text-md font-bold text-gray-900 mt-2">
                      {line.replace(/#/g, '')}
                    </h3>
                  );
                } else if (line.includes('**')) {
                  // Render bold text (**anytext** -> as bold)
                  const parts = line.split(/\*\*/);
                  return (
                    <p key={index}>
                      {parts.map((part, i) =>
                        i % 2 === 1 ? (
                          <span key={i} className="font-bold">
                            {part}
                          </span>
                        ) : (
                          part
                        )
                      )}
                    </p>
                  );
                } else {
                  // Render normal text
                  return <p key={index}>{line}</p>;
                }
              })}
            </div>
            <button
              onClick={closeModal}
              className="mt-4 p-2 bg-blue-500 text-white rounded-lg w-full hover:bg-blue-600 transition">
              Close
            </button>
          </div>
        </div>
      )}

        {isLoadingFeedback && (
          <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <h2 className="text-lg font-semibold text-yellow-800">Fetching feedback...</h2>
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default RolePlaySession;
