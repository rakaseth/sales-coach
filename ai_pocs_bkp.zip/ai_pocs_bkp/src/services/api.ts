import { ApiResponse, CallEvaluation, ScenarioResponse } from '../types';

const API_BASE_URL = '/api';

export async function generateScenario(params: {
  topic: string;
  company: string;
  tone: string;
}): Promise<ScenarioResponse> {
  const response = await fetch(`${API_BASE_URL}/ScenarioGenerator`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  return response.json();
}

export async function evaluateCall(transcript: string): Promise<CallEvaluation> {
  const response = await fetch(`${API_BASE_URL}/evaluateCall`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ transcript }),
  });
  return response.json();
}

export async function evaluateGongCall(params: {
  apiKey: string;
  username: string;
  callId: string;
}): Promise<CallEvaluation> {
  const response = await fetch(`${API_BASE_URL}/evaluateCall`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ...params, source: 'gong' }),
  });
  return response.json();
}