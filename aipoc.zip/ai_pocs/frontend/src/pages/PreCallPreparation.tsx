import React, { useState } from 'react'
import { Search, FileCheck, Loader, X, CheckCircle, AlertCircle, Download } from 'lucide-react'

interface ResearchForm {
  companyName: string
  additionalContext: string
  lastCallDate: string
}

interface AlertType {
  message: string
  type: 'success' | 'error'
}

interface SimpleMarkdownProps {
  content: string | null // Allow content to be null
}

interface ResearchResultModalProps {
  result: string | null // Allow result to be null
  companyName: string
  onClose: () => void
  onDownload: () => void
}

const SimpleMarkdown: React.FC<SimpleMarkdownProps> = ({ content }) => {
  const formatMarkdown = (text: string | null) => {
    if (!text) return []

    const lines = text.split('\n')
    
    return lines.map((line, index) => {
      if (line.startsWith('# ')) {
        return <h1 key={index} className="text-2xl font-bold my-4">{line.slice(2)}</h1>
      }
      if (line.startsWith('## ')) {
        return <h2 key={index} className="text-xl font-bold my-3">{line.slice(3)}</h2>
      }
      if (line.startsWith('### ')) {
        return <h3 key={index} className="text-lg font-bold my-2">{line.slice(4)}</h3>
      }

      if (line.startsWith('- ')) {
        return <li key={index} className="ml-4 my-1">{line.slice(2)}</li>
      }
      if (line.match(/^\d+\. /)) {
        return <li key={index} className="ml-4 my-1">{line.slice(line.indexOf(' ') + 1)}</li>
      }

      let formatted = line
      formatted = formatted.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      formatted = formatted.replace(/\*(.*?)\*/g, '<em>$1</em>')
      
      if (!line.trim()) {
        return <br key={index} />
      }

      return <p key={index} className="my-2" dangerouslySetInnerHTML={{ __html: formatted }} />
    })
  }

  return (
    <div className="space-y-2">
      {formatMarkdown(content)}
    </div>
  )
}

const ResearchResultModal: React.FC<ResearchResultModalProps> = ({ 
  result, 
  companyName, 
  onClose, 
  onDownload 
}) => {
  console.log('Modal received result:', result)
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white w-11/12 max-w-4xl max-h-[90vh] rounded-lg shadow-2xl flex flex-col">
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-2xl font-bold text-blue-800">
            Research Results for {companyName}
          </h2>
          <div className="flex items-center space-x-2">
            <button 
              onClick={onDownload}
              className="text-blue-600 hover:bg-blue-50 p-2 rounded-full"
              title="Download Results"
            >
              <Download className="w-6 h-6" />
            </button>
            <button 
              onClick={onClose}
              className="text-red-600 hover:bg-red-50 p-2 rounded-full"
              title="Close"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        <div className="p-6 overflow-y-auto flex-grow">
          <SimpleMarkdown content={result} />
        </div>
      </div>
    </div>
  )
}

const PreCallPreparation: React.FC = () => {
  const [selectedOption, setSelectedOption] = useState<'research' | 'precall' | null>(null)
  const [loading, setLoading] = useState(false)
  const [researchForm, setResearchForm] = useState<ResearchForm>({
    companyName: '',
    additionalContext: '',
    lastCallDate: ''
  })
  const [researchResult, setResearchResult] = useState<string | null>(null)
  const [alert, setAlert] = useState<AlertType | null>(null)

  const showAlert = (message: string, type: 'success' | 'error') => {
    setAlert({ message, type })
    setTimeout(() => setAlert(null), 3000)
  }

  const handleResearchSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const response = await fetch('http://localhost:8002/api/researcher/researcher', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(researchForm),
      })

      if (!response.ok) {
        throw new Error('Network response was not ok')
      }

      const data = await response.json()
      console.log('API Response:', data)
      
      if (data) {
        setResearchResult(data)
        showAlert('Research completed successfully', 'success')
      } else {
        console.error('No response content found in:', data)
        showAlert('Research completed but no content received', 'error')
      }
    } catch (error) {
      console.error('Full error:', error)
      showAlert('Failed to complete research', 'error')
    } finally {
      setLoading(false)
    }
  }

  const handlePreCallSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const response = await fetch('http://localhost:8002/api/researcher/precall', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          companyName: researchForm.companyName,
          to_date: researchForm.lastCallDate,
          additional_context: researchForm.additionalContext
        }),
      })

      if (!response.ok) {
        throw new Error('Network response was not ok')
      }

      const data = await response.json()
      console.log('API Response:', data)

      if (data.response) {
        setResearchResult(data.response)
        showAlert('Pre-call preparation completed successfully', 'success')
      } else {
        console.error('No response content found in:', data.response)
        showAlert('Pre-call preparation completed but no content received', 'error')
      }
    } catch (error) {
      console.error('Full error:', error)
      showAlert('Failed to complete pre-call preparation', 'error')
    } finally {
      setLoading(false)
    }
  }

  const handleDownloadResult = () => {
    if (!researchResult) return

    const blob = new Blob([researchResult], { type: 'text/markdown' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `${researchForm.companyName}_${selectedOption}.md`
    link.click()
    URL.revokeObjectURL(url)
  }

  const handleCloseModal = () => {
    setResearchResult(null)
  }

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-4xl mx-auto bg-white shadow-lg rounded-lg overflow-hidden">
        {alert && (
          <div className={`fixed top-4 right-4 p-4 rounded-lg shadow-lg max-w-md flex items-center gap-2 transition-opacity duration-300 ${
            alert.type === 'success' 
              ? 'bg-green-50 text-green-800 border border-green-200' 
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}>
            {alert.type === 'success' 
              ? <CheckCircle className="h-5 w-5 text-green-500" /> 
              : <AlertCircle className="h-5 w-5 text-red-500" />
            }
            <span className="text-sm font-medium">{alert.message}</span>
            <button 
              onClick={() => setAlert(null)}
              className="ml-auto hover:opacity-70"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        )}

        <div className="bg-blue-600 text-white p-6">
          <h1 className="text-2xl font-bold">Pre-call Preparation Tools</h1>
        </div>

        <div className="p-6 border-b flex gap-4">
          <button
            onClick={() => setSelectedOption('research')}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg transition-colors ${
              selectedOption === 'research' 
                ? 'bg-blue-500 text-white' 
                : 'bg-white text-blue-500 border border-blue-500 hover:bg-blue-50'
            }`}
          >
            <Search className="w-5 h-5" />
            ResearcherAI
          </button>
          <button
            onClick={() => setSelectedOption('precall')}
            className={`flex items-center gap-2 px-6 py-3 rounded-lg transition-colors ${
              selectedOption === 'precall' 
                ? 'bg-green-500 text-white' 
                : 'bg-white text-green-500 border border-green-500 hover:bg-green-50'
            }`}
          >
            <FileCheck className="w-5 h-5" />
            Pre-call Preparation
          </button>
        </div>

        {selectedOption === 'research' && (
          <div className="p-6">
            <form onSubmit={handleResearchSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Company Name</label>
                <input
                  type="text"
                  value={researchForm.companyName}
                  onChange={(e) => setResearchForm(prev => ({ ...prev, companyName: e.target.value }))}
                  className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  placeholder="Enter company name"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Additional Context</label>
                <textarea
                  value={researchForm.additionalContext}
                  onChange={(e) => setResearchForm(prev => ({ ...prev, additionalContext: e.target.value }))}
                  className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  rows={4}
                  placeholder="Enter any additional context or specific areas to research"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-blue-500 text-white px-4 py-3 rounded-lg hover:bg-blue-600 disabled:bg-blue-300 flex items-center justify-center gap-2"
              >
                {loading ? <Loader className="w-5 h-5 animate-spin" /> : <Search className="w-5 h-5" />}
                {loading ? 'Researching...' : 'Start Research'}
              </button>
            </form>
          </div>
        )}

        {selectedOption === 'precall' && (
          <div className="p-6">
            <form onSubmit={handlePreCallSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Company Name</label>
                <input
                  type="text"
                  value={researchForm.companyName}
                  onChange={(e) => setResearchForm(prev => ({ ...prev, companyName: e.target.value }))}
                  className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  placeholder="Enter company name"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Last Call Date</label>
                <input
                  type="date"
                  value={researchForm.lastCallDate}
                  onChange={(e) => setResearchForm(prev => ({ ...prev, lastCallDate: e.target.value }))}
                  className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-green-500 text-white px-4 py-3 rounded-lg hover:bg-green-600 disabled:bg-green-300 flex items-center justify-center gap-2"
              >
                {loading ? <Loader className="w-5 h-5 animate-spin" /> : <FileCheck className="w-5 h-5" />}
                {loading ? 'Preparing...' : 'Prepare Call'}
              </button>
            </form>
          </div>
        )}

        {researchResult && (
          <ResearchResultModal 
            result={researchResult}
            companyName={researchForm.companyName}
            onClose={handleCloseModal}
            onDownload={handleDownloadResult}
          />
        )}
      </div>
    </div>
  )
}

export default PreCallPreparation