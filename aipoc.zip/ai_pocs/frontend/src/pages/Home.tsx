import { useNavigate } from 'react-router-dom'
import { BarChart2 } from 'lucide-react'

const Home = () => {
  const navigate = useNavigate()

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {/* Evaluation Dashboard Card */}
      <div className="bg-white p-6 rounded-lg shadow-lg">
        <div className="flex items-center justify-center mb-4">
          <div className="bg-blue-100 p-3 rounded-full">
            <BarChart2 className="w-6 h-6 text-blue-600" />
          </div>
        </div>
        
        <h2 className="text-xl font-bold mb-3 text-center text-gray-800">
          Evaluation Dashboard
        </h2>

        <p className="text-gray-600 text-sm mb-4 text-center">
          Analyze and evaluate your conversation data
        </p>

        <button
          onClick={() => navigate('/evaluation-form')}
          className="w-full bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors duration-200 text-sm font-semibold"
        >
          Start Evaluation
        </button>
      </div>

      {/* Additional cards can be added here */}
      {/* Example placeholder cards */}
      <div className="bg-white p-6 rounded-lg shadow-lg">
        <div className="h-full flex items-center justify-center text-gray-400">
          Add your content here
        </div>
      </div>
      
      <div className="bg-white p-6 rounded-lg shadow-lg">
        <div className="h-full flex items-center justify-center text-gray-400">
          Add your content here
        </div>
      </div>
    </div>
  )
}

export default Home