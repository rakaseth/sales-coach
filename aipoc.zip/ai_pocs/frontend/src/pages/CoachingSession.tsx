import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useLocation, useNavigate } from 'react-router-dom';
import { RetellWebClient } from 'retell-client-js-sdk';
import { AudioControls } from '../components/AudioControls';
import { AudioState } from '../types';

const agentId = "agent_cbd0814ca213c998f7be8fe3ec";
const retellWebClient = new RetellWebClient();

const CoachingSession = () => {
  const location = useLocation();
  const navigate = useNavigate();
  
  const [audioState, setAudioState] = useState<AudioState>({
    isConnected: false,
    isCallActive: false,
    error: null,
    timeRemaining: 300
  });
  const [isCalling, setIsCalling] = useState(false);
  const [coachType, setCoachType] = useState('');
  const [instruction, setInstruction] = useState('');
  const [useKnowledgeBase, setUseKnowledgeBase] = useState(false);
  const [isInputModalOpen, setIsInputModalOpen] = useState(true); // Open modal by default
  const [files, setFiles] = useState<File[]>([]); // Changed to handle multiple files
  const [knowledge, setKnowledge] = useState(null); // State to hold knowledge from file upload
  const [uploadStatus, setUploadStatus] = useState(''); // State to manage upload status

  useEffect(() => {
    retellWebClient.on("call_started", () => {
      setIsCalling(true);
      setAudioState(prev => ({ ...prev, isConnected: true }));
    });

    retellWebClient.on("call_ended", () => {
      setIsCalling(false);
      setAudioState(prev => ({ ...prev, isCallActive: false, isConnected: false }));
      setIsInputModalOpen(true); // Show input modal again when call ends
    });

    retellWebClient.on("error", (error) => {
      console.error("Error:", error);
      retellWebClient.stopCall();
      setIsCalling(false);
      setAudioState(prev => ({ ...prev, error: error.message }));
    });

    return () => {
      retellWebClient.removeAllListeners();
    };
  }, []);

  const handleSubmit = () => {
    setIsInputModalOpen(false);
    toggleConversation();
  };

  const toggleConversation = async () => {
    if (isCalling) {
      retellWebClient.stopCall();
    } else {
      try {
        const response = await fetch("http://localhost:8002/api/retell/register-retell-web-call", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ 
            agent_id: agentId, 
            coachType: coachType,
            instruction: instruction,
            useKnowledgeBase: useKnowledgeBase,
            tempknowledge: files.length > 0 ? knowledge : "" // Send empty string if no files uploaded
          })
        });

        if (response.ok) {
          const { access_token } = await response.json();
          await retellWebClient.startCall({ accessToken: access_token });
          setAudioState(prev => ({ ...prev, isCallActive: true }));
        } else {
          throw new Error(`Call start failed with status ${response.status}`);
        }
      } catch (error) {
        console.error("Error starting call:", error);
        setAudioState(prev => ({ ...prev, error: 'Failed to start call' }));
      }
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFiles = event.target.files;
    if (uploadedFiles) {
      const newFiles = Array.from(uploadedFiles);
      setFiles(prevFiles => [...prevFiles, ...newFiles]); // Update state to include new files
    }
  };

  const uploadFiles = async () => {
    if (files.length === 0) return; // Prevent upload if no files

    const formData = new FormData();
    files.forEach(file => formData.append('files', file)); // Append each file to FormData

    setUploadStatus('Uploading...'); // Set upload status to uploading

    try {
      const response = await fetch("http://localhost:8002/api/context/sessioncontext", {
        method: "POST",
        body: formData,
      });

      if (response.ok) {
        const knowledgeData = await response.json(); // Assuming the response contains knowledge
        setKnowledge(knowledgeData.knowledge); // Store the knowledge in state
        setUploadStatus('Upload Done ✔️'); // Update status to upload done
      } else {
        throw new Error(`File upload failed with status ${response.status}`);
      }
    } catch (error) {
      console.error("Error uploading files:", error);
      setUploadStatus('Upload Failed'); // Update status to upload failed
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <aside className="w-1/4 p-4 bg-white shadow-md">
        <h2 className="text-lg font-semibold mb-2">Upload Session Context</h2>
        <input 
          type="file" 
          onChange={handleFileUpload} 
          className="mb-4"
          multiple // Allow multiple file selection
        />
        <button 
          onClick={uploadFiles} 
          className="bg-blue-500 text-white px-4 py-2 rounded"
        >
          {uploadStatus || 'Upload Files'} {/* Display upload status */}
        </button>
      </aside>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="max-w-4xl mx-auto p-6 w-3/4"
      >
        <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
          <h1 className="text-2xl font-bold text-gray-800">Coaching Session</h1>
        </div>

        {isInputModalOpen && (
          <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-2">Coach Type</h2>
            <input 
              type="text" 
              placeholder="Enter coach type..."
              value={coachType}
              onChange={(e) => setCoachType(e.target.value)}
              className="p-2 border rounded w-full mb-4"
            />
            <label className="flex items-center mb-4">
              <input 
                type="checkbox" 
                checked={useKnowledgeBase} 
                onChange={(e) => setUseKnowledgeBase(e.target.checked)} 
                className="mr-2"
              />
              Use existing knowledge base
            </label>
            <h2 className="text-xl font-semibold text-gray-800 mb-2">Instructions</h2>
            <textarea 
              className="mt-2 p-2 border rounded w-full mb-4"
              placeholder="Enter additional instructions..."
              value={instruction}
              onChange={(e) => setInstruction(e.target.value)}
            />
            <button 
              onClick={handleSubmit} 
              className="bg-green-500 text-white px-4 py-2 rounded"
            >
              Submit
            </button>
          </div>
        )}

        {isCalling && (
          <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-2">Call in Progress</h2>
            <p>Coach Type: {coachType}</p>
            <p>Instructions: {instruction}</p>
          </div>
        )}

        <AudioControls
          audioState={audioState}
          onStartCall={toggleConversation}
          onEndCall={toggleConversation}
        />

        {audioState.error && (
          <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-red-600">{audioState.error}</p>
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default CoachingSession;