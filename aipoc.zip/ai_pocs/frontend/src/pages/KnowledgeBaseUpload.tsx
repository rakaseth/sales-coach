import React, { useState } from 'react';

const KnowledgeBaseUpload: React.FC = () => {
  const [selectedFiles, setSelectedFiles] = useState<FileList | null>(null);
  const [uploadStatus, setUploadStatus] = useState<string>(''); 
  const [isUploading, setIsUploading] = useState<boolean>(false); // New state to track uploading status

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    setSelectedFiles(files);
  };

  const handleUpload = async () => {
    if (!selectedFiles || selectedFiles.length === 0) {
      setUploadStatus('Please select at least one file first.');
      return;
    }

    const formData = new FormData();
    Array.from(selectedFiles).forEach(file => {
      formData.append('files', file);
    });

    setIsUploading(true); // Set uploading state to true

    try {
      const response = await fetch('http://localhost:8002/api/knowledge/knowledge_base', {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        setUploadStatus('Files uploaded successfully! ✔️'); // Update status with tick mark
      } else {
        const error = await response.text();
        setUploadStatus(`Error: ${error}`);
      }
    } catch (err) {
      setUploadStatus('Error uploading the files. Please try again.');
      console.error('Upload error:', err);
    } finally {
      setIsUploading(false); // Reset uploading state
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center">
      <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
        <h2 className="text-2xl font-bold mb-4 text-center">Upload Knowledge Base</h2>
        <input
          type="file"
          onChange={handleFileChange}
          className="block w-full text-gray-700 mb-4"
          multiple
        />
        <button
          onClick={handleUpload}
          className="w-full bg-orange-500 hover:bg-orange-600 text-white py-2 px-4 rounded"
        >
          {isUploading ? 'Uploading...' : 'Upload'} {/* Change button text based on uploading state */}
        </button>
        {uploadStatus && <p className="mt-4 text-center">{uploadStatus}</p>}
      </div>
    </div>
  );
};

export default KnowledgeBaseUpload;