import React, { useState } from 'react';
import { Upload } from 'lucide-react';
//import { evaluateCall, evaluateGongCall } from '../services/api';
import EvaluationResult from '../components/EvaluationResult';
import type { CallEvaluation } from '../types';

export default function EvaluateConversation() {
  const [transcript, setTranscript] = useState('');
  const [whomToEvaluate, setWhomToEvaluate] = useState(''); // New state for whom to evaluate
  const [gongConfig, setGongConfig] = useState({
    apiKey: '',
    username: '',
    callId: ''
  });
  const [evaluation, setEvaluation] = useState<CallEvaluation | null>(null);
  const [activeTab, setActiveTab] = useState<'upload' | 'gong'>('upload');
  const [loading, setLoading] = useState(false); // New loading state

  const handleTranscriptSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:8002/evaluateCall", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ transcript, whomToEvaluate }) // Pass whomToEvaluate
      });
      const result = await response.json(); // Assuming the response is JSON
      setEvaluation(result); // Set evaluation with the response
    } catch (error) {
      console.error('Failed to evaluate transcript:', error);
    } 
  };

  const handleGongSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true); // Set loading to true when the button is pressed
    try {
      const response = await fetch("http://localhost:8002/evaluategongcall", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          accesskey:  gongConfig.username,
          secretkey: gongConfig.apiKey,
          callid: gongConfig.callId
        })
      });
      const result = await response.json();
      console.log("result", result);
      setEvaluation(result);
    } catch (error) {
      console.error('Failed to evaluate Gong call:', error);
    } finally {
      setLoading(false); // Set loading to false after the response is received
    }
  };

  return (
    <div className="container mx-auto px-4 py-12 max-w-2xl">
      <h1 className="text-3xl font-bold mb-8">Evaluate Conversation</h1>

      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex mb-6">
          <button
            className={`flex-1 py-2 text-center ${
              activeTab === 'upload'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-gray-500'
            }`}
            onClick={() => setActiveTab('upload')}
          >
            Upload Transcript
          </button>
          <button
            className={`flex-1 py-2 text-center ${
              activeTab === 'gong'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-gray-500'
            }`}
            onClick={() => setActiveTab('gong')}
          >
            Gong Integration
          </button>
        </div>

        {activeTab === 'upload' ? (
          <form onSubmit={handleTranscriptSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Conversation Transcript
              </label>
              <textarea
                className="w-full h-64 p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                value={transcript}
                onChange={(e) => setTranscript(e.target.value)}
                placeholder="Paste your conversation transcript here..."
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Whom to Evaluate
              </label>
              <input
                type="text"
                className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                value={whomToEvaluate}
                onChange={(e) => setWhomToEvaluate(e.target.value)} // Input for whom to evaluate
                placeholder="Enter the name of the person to evaluate..."
                required
              />
            </div>
            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
            >
              <Upload className="w-5 h-5" />
              Evaluate Transcript
            </button>
          </form>
        ) : (
          <form onSubmit={handleGongSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
              GONG_SECRET_KEY
              </label>
              <input
                type="password"
                className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                value={gongConfig.apiKey}
                onChange={(e) =>
                  setGongConfig((prev) => ({ ...prev, apiKey: e.target.value }))
                }
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
              GONG_ACCESS_KEY
              </label>
              <input
                type="password" // Changed to password type
                className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                value={gongConfig.username}
                onChange={(e) =>
                  setGongConfig((prev) => ({ ...prev, username: e.target.value }))
                }
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Call ID
              </label>
              <input
                type="text"
                className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                value={gongConfig.callId}
                onChange={(e) =>
                  setGongConfig((prev) => ({ ...prev, callId: e.target.value }))
                }
                required
              />
            </div>
            <button
              type="submit"
              className={`w-full ${loading ? 'bg-orange-600' : 'bg-blue-600'} text-white py-3 rounded-lg transition-colors flex items-center justify-center gap-2`}
            >
              {loading ? (
                <span>Loading...</span> // Show loading text while waiting for response
              ) : (
                'Evaluate Gong Call'
              )}
            </button>
          </form>
        )}
      </div>

      {evaluation && (
        <EvaluationResult
          evaluation={evaluation}
          onClose={() => setEvaluation(null)}
        />
      )}
    </div>
  );
}