import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Award, ChevronLeft, ThumbsUp, Lightbulb } from 'lucide-react';
import { FeedbackData } from '../types';

const FeedbackPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { messages, topic, company } = location.state || {};
  const [feedback, setFeedback] = useState<FeedbackData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!messages) {
      navigate('/role-play/setup');
      return;
    }

    const fetchFeedback = async () => {
      try {
        const response = await fetch('http://localhost:8000/api/analyze-conversation', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ messages, topic, company }),
        });

        if (response.ok) {
          const data = await response.json();
          setFeedback(data);
        }
      } catch (error) {
        console.error('Error fetching feedback:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchFeedback();
  }, [messages, topic, company, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-600">Analyzing your conversation...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="max-w-4xl mx-auto"
      >
        <div className="mb-8 flex items-center justify-between">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-800 transition-colors"
          >
            <ChevronLeft className="w-5 h-5" />
            Back to Home
          </button>
          <h1 className="text-2xl font-bold text-gray-800">Conversation Analysis</h1>
        </div>

        {feedback && (
          <div className="space-y-6">
            {/* Deal Summary */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-xl shadow-sm p-6"
            >
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Award className="w-5 h-5 text-blue-500" />
                Deal Summary
              </h2>
              <p className="text-gray-700 leading-relaxed">{feedback.dealSummary}</p>
            </motion.div>

            {/* Overall Impression */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white rounded-xl shadow-sm p-6"
            >
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <ThumbsUp className="w-5 h-5 text-green-500" />
                What Went Well
              </h2>
              <ul className="space-y-3">
                {feedback.whatWentWell.map((point, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <div className="flex-shrink-0 w-1.5 h-1.5 rounded-full bg-green-500 mt-2"></div>
                    <p className="text-gray-700">{point}</p>
                  </li>
                ))}
              </ul>
            </motion.div>

            {/* Growth Opportunities */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white rounded-xl shadow-sm p-6"
            >
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Lightbulb className="w-5 h-5 text-amber-500" />
                Growth Opportunities
              </h2>
              <ul className="space-y-3">
                {feedback.growthOpportunities.map((point, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <div className="flex-shrink-0 w-1.5 h-1.5 rounded-full bg-amber-500 mt-2"></div>
                    <p className="text-gray-700">{point}</p>
                  </li>
                ))}
              </ul>
            </motion.div>
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default FeedbackPage;