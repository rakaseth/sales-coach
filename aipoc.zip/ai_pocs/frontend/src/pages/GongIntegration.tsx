
import { useState, useEffect } from 'react'
import { toast } from 'react-hot-toast'

const GongIntegration = () => {
  const [credentials, setCredentials] = useState({
    accessKey: '',
    secretKey: ''
  })

  useEffect(() => {
    const savedCredentials = localStorage.getItem('gongCredentials')
    if (savedCredentials) {
      setCredentials(JSON.parse(savedCredentials))
    }
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    localStorage.setItem('gongCredentials', JSON.stringify(credentials))
    toast.success('Gong credentials saved successfully')
  }

  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Gong Integration</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">Gong Access Key</label>
          <input
            type="text"
            value={credentials.accessKey}
            onChange={(e) => setCredentials(prev => ({ ...prev, accessKey: e.target.value }))}
            className="w-full p-2 border rounded-lg"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Gong Secret Key</label>
          <input
            type="password"
            value={credentials.secretKey}
            onChange={(e) => setCredentials(prev => ({ ...prev, secretKey: e.target.value }))}
            className="w-full p-2 border rounded-lg"
            required
          />
        </div>
        <button
          type="submit"
          className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600"
        >
          Save Credentials
        </button>
      </form>
    </div>
  )
}

export default GongIntegration
