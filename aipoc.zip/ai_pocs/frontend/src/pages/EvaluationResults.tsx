import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Clock, Users, AlertCircle, CheckCircle, ChevronRight, BarChart2 } from 'lucide-react'

interface User {
  name: string
  email: string
}

interface Evaluation {
  internal_user?: User[]
  external_user?: User[]
  summary?: string
  internal_performance?: string
  external_pain_points?: string[]
  missed_opportunities?: string[]
  overall_call_outcome?: string
}

interface Result {
  call_id?: string
  evaluation?: Evaluation
  event_date?: string
  call_duration?: number
}

interface PainPointStat {
  point: string
  count: number
}

interface ParticipantStat {
  name: string
  email: string
  callCount: number
}

const EvaluationResults = () => {
  const navigate = useNavigate()
  const [results, setResults] = useState<Result[]>([])
  const [expandedCallId, setExpandedCallId] = useState<string | null>(null)
  const [painPointStats, setPainPointStats] = useState<PainPointStat[]>([])
  const [internalParticipants, setInternalParticipants] = useState<ParticipantStat[]>([])
  const [externalParticipants, setExternalParticipants] = useState<ParticipantStat[]>([])
  const [expandedPainPoints, setExpandedPainPoints] = useState(false)
  const [expandedParticipants, setExpandedParticipants] = useState(false)

  useEffect(() => {
    try {
      const savedResults = localStorage.getItem('evaluationResults')
      if (!savedResults) {
        navigate('/evaluation-form')
        return
      }
      const parsedResults = JSON.parse(savedResults)
      const sortedResults = (Array.isArray(parsedResults) ? parsedResults : [parsedResults])
        .sort((a, b) => new Date(b.event_date || '').getTime() - new Date(a.event_date || '').getTime())
      setResults(sortedResults)

      // Calculate pain point statistics
      const painPointsMap = new Map<string, number>()
      sortedResults.forEach(result => {
        result.evaluation?.external_pain_points?.forEach(point => {
          painPointsMap.set(point, (painPointsMap.get(point) || 0) + 1)
        })
      })
      const sortedPainPoints = Array.from(painPointsMap.entries())
        .map(([point, count]) => ({ point, count }))
        .sort((a, b) => a.count - b.count) // Sort from oldest to newest
      setPainPointStats(sortedPainPoints)

      // Calculate participant statistics
      const internalMap = new Map<string, ParticipantStat>()
      const externalMap = new Map<string, ParticipantStat>()

      sortedResults.forEach(result => {
        result.evaluation?.internal_user?.forEach(user => {
          const existing = internalMap.get(user.email) || { ...user, callCount: 0 }
          internalMap.set(user.email, { ...existing, callCount: existing.callCount + 1 })
        })
        result.evaluation?.external_user?.forEach(user => {
          const existing = externalMap.get(user.email) || { ...user, callCount: 0 }
          externalMap.set(user.email, { ...existing, callCount: existing.callCount + 1 })
        })
      })

      setInternalParticipants(Array.from(internalMap.values()).sort((a, b) => b.callCount - a.callCount))
      setExternalParticipants(Array.from(externalMap.values()).sort((a, b) => b.callCount - a.callCount))
    } catch (error) {
      console.error('Error parsing results:', error)
      navigate('/evaluation-form')
    }
  }, [navigate])

  const formatDuration = (seconds: number = 0) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes}m ${remainingSeconds}s`
  }

  const formatDate = (dateString: string = '') => {
    try {
      return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      })
    } catch {
      return 'Invalid Date'
    }
  }

  const toggleExpand = (callId: string = '') => {
    setExpandedCallId(expandedCallId === callId ? null : callId)
  }

  const toggleExpandPainPoints = () => {
    setExpandedPainPoints(!expandedPainPoints)
  }

  const toggleExpandParticipants = () => {
    setExpandedParticipants(!expandedParticipants)
  }

  if (!results.length) return (
    <div className="text-center py-10">
      <p className="text-gray-600">No evaluation results available.</p>
    </div>
  )

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold mb-6">Evaluation Analysis</h1>

      {/* Summary Statistics Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Common Pain Points */}
        <div className="bg-white shadow rounded-lg p-6">
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <BarChart2 className="w-5 h-5 text-red-500" />
            Common Pain Points
          </h2>
          <div className="space-y-3">
            {painPointStats.slice(0, expandedPainPoints ? painPointStats.length : 3).map((stat, index) => (
              <div key={index} className="flex justify-between items-center">
                <span className="text-sm text-gray-700">{stat.point}</span>
                <span className="text-sm font-semibold bg-red-100 text-red-600 px-2 py-1 rounded">
                  {stat.count} times
                </span>
              </div>
            ))}
          </div>
          <button
            onClick={toggleExpandPainPoints}
            className="flex items-center text-blue-500 hover:text-blue-600 text-sm font-medium mt-2"
          >
            {expandedPainPoints ? 'Show Less' : 'Continue'}
            <ChevronRight className="w-4 h-4 ml-1" />
          </button>
        </div>

        {/* Frequent Participants */}
        <div className="bg-white shadow rounded-lg p-6">
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-500" />
            Frequent Participants
          </h2>
          
          {/* Internal Participants */}
          <div className="mb-4">
            <h3 className="text-sm font-medium text-gray-600 mb-2">Internal Team</h3>
            <div className="space-y-2">
              {internalParticipants.slice(0, expandedParticipants ? internalParticipants.length : 3).map((participant, index) => (
                <div key={index} className="flex justify-between items-center">
                  <div className="text-sm">
                    <span className="font-medium">{participant.name}</span>
                    <span className="text-gray-500 text-xs ml-2">({participant.email})</span>
                  </div>
                  <span className="text-sm font-semibold bg-blue-100 text-blue-600 px-2 py-1 rounded">
                    {participant.callCount} calls
                  </span>
                </div>
              ))}
            </div>
            <button
              onClick={toggleExpandParticipants}
              className="flex items-center text-blue-500 hover:text-blue-600 text-sm font-medium mt-2"
            >
              {expandedParticipants ? 'Show Less' : 'Continue'}
              <ChevronRight className="w-4 h-4 ml-1" />
            </button>
          </div>

          {/* External Participants */}
          <div>
            <h3 className="text-sm font-medium text-gray-600 mb-2">External Participants</h3>
            <div className="space-y-2">
              {externalParticipants.slice(0, expandedParticipants ? externalParticipants.length : 3).map((participant, index) => (
                <div key={index} className="flex justify-between items-center">
                  <div className="text-sm">
                    <span className="font-medium">{participant.name}</span>
                    <span className="text-gray-500 text-xs ml-2">({participant.email})</span>
                  </div>
                  <span className="text-sm font-semibold bg-green-100 text-green-600 px-2 py-1 rounded">
                    {participant.callCount} calls
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Individual Call Evaluations */}
      <h2 className="text-xl font-semibold mb-4">Individual Call Evaluations</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {results.map((result, index) => (
          <div key={result.call_id || index} className="bg-white shadow rounded-lg overflow-hidden">
            {/* Compact View */}
            <div className="p-4">
              <div className="flex justify-between items-start mb-3">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 text-sm text-gray-600 mb-2">
                    <Clock className="w-4 h-4" />
                    <span>{formatDate(result.event_date)}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <Users className="w-4 h-4" />
                    <span>{result.evaluation?.internal_user?.[0]?.name || 'Unknown'}</span>
                  </div>
                </div>
                <div className="text-sm text-gray-500">
                  {formatDuration(result.call_duration)}
                </div>
              </div>
              
              {result.evaluation?.summary && (
                <p className="text-sm text-gray-700 line-clamp-2 mb-3">
                  {result.evaluation.summary}
                </p>
              )}

              <button
                onClick={() => toggleExpand(result.call_id)}
                className="flex items-center text-blue-500 hover:text-blue-600 text-sm font-medium"
              >
                {expandedCallId === result.call_id ? 'Show Less' : 'Continue'}
                <ChevronRight className="w-4 h-4 ml-1" />
              </button>
            </div>

            {/* Expanded View */}
            {expandedCallId === result.call_id && (
              <div className="border-t border-gray-100 p-4 space-y-4">
                {/* Rest of the expanded view content remains the same */}
                {/* Participants */}
                <div className="space-y-3">
                  <h3 className="text-sm font-semibold flex items-center gap-2">
                    <Users className="w-4 h-4" />
                    Participants
                  </h3>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <h4 className="text-xs font-medium mb-1">Internal Users</h4>
                      {(result.evaluation?.internal_user || []).map((user, idx) => (
                        <div key={idx} className="text-xs">
                          <p className="font-medium">{user.name}</p>
                          <p className="text-gray-600">{user.email}</p>
                        </div>
                      ))}
                    </div>
                    <div>
                      <h4 className="text-xs font-medium mb-1">External Users</h4>
                      {(result.evaluation?.external_user || []).map((user, idx) => (
                        <div key={idx} className="text-xs">
                          <p className="font-medium">{user.name}</p>
                          <p className="text-gray-600">{user.email}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Performance */}
                {result.evaluation?.internal_performance && (
                  <div>
                    <h3 className="text-sm font-semibold mb-1">Internal Performance</h3>
                    <p className="text-sm text-gray-700">{result.evaluation.internal_performance}</p>
                  </div>
                )}

                {/* Pain Points */}
                {result.evaluation?.external_pain_points && result.evaluation.external_pain_points.length > 0 && (
                  <div>
                    <h3 className="text-sm font-semibold flex items-center gap-2 mb-1">
                      <AlertCircle className="w-4 h-4" />
                      External Pain Points
                    </h3>
                    <ul className="list-disc list-inside space-y-1">
                      {result.evaluation.external_pain_points.map((point, idx) => (
                        <li key={idx} className="text-sm text-gray-700">{point}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Missed Opportunities */}
                {result.evaluation?.missed_opportunities && result.evaluation.missed_opportunities.length > 0 && (
                  <div>
                    <h3 className="text-sm font-semibold flex items-center gap-2 mb-1">
                      <AlertCircle className="w-4 h-4" />
                      Missed Opportunities
                    </h3>
                    <ul className="list-disc list-inside space-y-1">
                      {result.evaluation.missed_opportunities.map((opportunity, idx) => (
                        <li key={idx} className="text-sm text-gray-700">{opportunity}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Overall Outcome */}
                {result.evaluation?.overall_call_outcome && (
                  <div>
                    <h3 className="text-sm font-semibold flex items-center gap-2 mb-1">
                      <CheckCircle className="w-4 h-4" />
                      Overall Call Outcome
                    </h3>
                    <p className="text-sm text-gray-700">{result.evaluation.overall_call_outcome}</p>
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

export default EvaluationResults