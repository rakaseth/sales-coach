import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Users, Brain, BarChart3, FilePlus } from 'lucide-react'; // Added FilePlus icon for upload
import { motion } from 'framer-motion';

const LandingPage = () => {
  const navigate = useNavigate();

  const cards = [
    {
      title: 'Role Play',
      description: 'Practice real-world scenarios with AI-powered conversations',
      icon: Users,
      path: '/role-play/setup',
      color: 'from-blue-500 to-blue-600',
    },
    {
      title: 'Talk to Coach',
      description: 'Get personalized guidance from an AI coach',
      icon: Brain,
      path: '/coaching',
      color: 'from-purple-500 to-purple-600',
    },
    {
      title: 'Evaluate Conversations',
      description: 'Review and analyze your past conversations',
      icon: BarChart3,
      path: '/evaluate',
      color: 'from-emerald-500 to-emerald-600',
    },
    {
      title: 'Upload Knowledge Base',
      description: 'Upload a PDF or ZIP file containing your knowledge base',
      icon: FilePlus,
      path: '/upload',
      color: 'from-orange-500 to-orange-600',
    },
    {
      title: 'Post Call Helper',
      description: 'Evaluate company performance using Gong insights',
      icon: BarChart3, // Reusing the BarChart3 icon
      path: '/evaluation-options',
      color: 'from-red-500 to-red-600',
    },
    {
      title: 'Pre Call Preparation With Coach',
      description: 'Evaluate company performance using Gong insights',
      icon: BarChart3, // Reusing the BarChart3 icon
      path: '/precall_helper',
      color: 'from-red-500 to-red-600',
    },
  ];

  return (
    <div className="min-h-screen p-8">
      <div className="max-w-6xl mx-auto">
        <motion.h1 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl font-bold text-center mb-12 text-gray-800"
        >
          AI-Powered Communication Training
        </motion.h1>

        <div className="grid md:grid-cols-3 gap-8">
          {cards.map((card, index) => (
            <motion.div
              key={card.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              onClick={() => navigate(card.path)}
              className="cursor-pointer group"
            >
              <div className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
                <div className={`bg-gradient-to-r ${card.color} p-6`}>
                  <card.icon className="w-12 h-12 text-white" />
                </div>
                <div className="p-6">
                  <h2 className="text-xl font-semibold mb-2 text-gray-800 group-hover:text-blue-600 transition-colors">
                    {card.title}
                  </h2>
                  <p className="text-gray-600">
                    {card.description}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LandingPage;