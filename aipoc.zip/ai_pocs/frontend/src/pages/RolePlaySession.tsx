import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Settings } from 'lucide-react';
import { ChatMessage } from '../components/ChatMessage';
import { AudioControls } from '../components/AudioControls';
import { Message, AudioState } from '../types';
import { RetellWebClient } from 'retell-client-js-sdk';
const agentId = "agent_5f0c2a79cf716573126d3de47f";
const retellWebClient = new RetellWebClient();

interface Scenario {
  title: string;
  description: string;
  role_play: {
    user: string[];
    other_person: string[];
  };
  things_to_be_pitched: string[];
  references: string[];
}

interface FeedbackData {
  feedback: string;
  score: number;
  missed_to_pitch: string[];
  what_went_well: string[];
  what_can_improve: string[];
  next_steps: string[];
  suggestions: string[];
  comments: string;
}

const RolePlaySession = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { topic, srccompany, dstcompany, coachrole, userrole, tone, scenario } = location.state || {};
  console.log("Topic:", topic);
  console.log("Source Company:", srccompany);
  console.log("Destination Company:", dstcompany);
  console.log("Coach Role:", coachrole);
  console.log("User Role:", userrole);
  console.log("Tone:", tone);
  console.log("Scenario:", scenario);

  const [messages, setMessages] = useState<Message[]>([]);
  const [audioState, setAudioState] = useState<AudioState>({
    isConnected: false,
    isCallActive: false,
    error: null,
    timeRemaining: 300
  });
  const [isCalling, setIsCalling] = useState(false);
  const [feedbackData, setFeedbackData] = useState<FeedbackData | null>(null);
  const [isLoadingFeedback, setIsLoadingFeedback] = useState(false);
  const [isFeedbackModalOpen, setIsFeedbackModalOpen] = useState(false);
  const [selectedScenario, setSelectedScenario] = useState<number | null>(0);
  const [callId, setCallId] = useState<string | null>(null);  
  const scenarios: Scenario[] = scenario || [];

  // Redirect to setup if essential data is missing
  if (!topic || !srccompany || !dstcompany) {
    navigate('/role-play/setup');
  }

  useEffect(() => {
    // Event listeners for call actions
    retellWebClient.on("call_started", () => setIsCalling(true));
    retellWebClient.on("call_ended", () => {
      setIsCalling(false);
      setAudioState((prev) => ({ ...prev, isCallActive: false }));
      if (callId) { // Only fetch feedback if callId exists
        fetchFeedback();
      }
    });
    retellWebClient.on("error", (error) => {
      console.error("Error:", error);
      retellWebClient.stopCall();
      setIsCalling(false);
    });

    return () => {
      retellWebClient.removeAllListeners();
    };
  }, [callId]); // Add callId as a dependency

  const fetchFeedback = async () => {
    if (!callId) {
      console.error("Cannot fetch feedback: callId is null");
      return;
    }

    setIsLoadingFeedback(true);
    try {
      const response = await fetch("http://localhost:8002/api/evaluate/evaluate-roleplay", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          call_id: callId,
          scenario: scenario[selectedScenario]
        })
      });
      if (!response.ok) {
        throw new Error(`Feedback fetch failed with status ${response.status}`);
      }

      const feedbackData: FeedbackData = await response.json();
      setFeedbackData(feedbackData);
      setIsFeedbackModalOpen(true);
    } catch (error) {
      console.error("Error fetching feedback:", error);
    } finally {
      setIsLoadingFeedback(false);
    }
  };

  const toggleConversation = async () => {
    if (isCalling) {
      retellWebClient.stopCall();
    } else {
      try {
        const response = await fetch("http://localhost:8002/api/retell/register-retell-web-call", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ 
            agent_id: agentId,
            tone: tone, 
            scenario: scenario[selectedScenario],
            srccompany: srccompany, 
            dstcompany: dstcompany, 
            coachrole: coachrole, 
            userrole: userrole,
            coachType: "roleplay"  
          })
        });

        if (response.ok) {
          const { access_token, call_id } = await response.json();
          setCallId(call_id); // Set the call_id in state
          await retellWebClient.startCall({ accessToken: access_token });
          setAudioState((prev) => ({ ...prev, isCallActive: true }));
        } else {
          throw new Error(`Call start failed with status ${response.status}`);
        }
      } catch (error) {
        console.error("Error starting call:", error);
      }
    }
  };


  const closeModal = () => setIsFeedbackModalOpen(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-7xl mx-auto p-4">
        <div className="bg-white rounded-lg shadow-sm p-4 mb-4 flex items-center justify-between">
          <h1 className="text-xl font-semibold text-gray-800">
            Role-Play Scenarios
          </h1>
          <button onClick={() => navigate('/role-play/setup')} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
            <Settings className="w-6 h-6 text-gray-600" />
          </button>
        </div>

        <div className="mb-4">
          {scenarios.map((sc, index) => (
            <div key={index} className="mb-4">
              <button
                onClick={() => setSelectedScenario(index)}
                className="w-full text-left p-4 bg-gray-100 rounded-lg border border-gray-300 hover:bg-gray-200 transition-colors"
              >
                {sc.title}
              </button>
              {selectedScenario === index && (
                <div className="mt-2 p-4 bg-white rounded-lg shadow-sm border border-gray-300">
                  <p className="text-gray-700 mb-2">{sc.description}</p>
                  <h3 className="text-md font-bold text-gray-900 mt-2">Role Play:</h3>
                  <ul className="list-disc list-inside text-gray-700 mb-2">
                    {sc.role_play.user.map((item, idx) => (
                      <li key={idx}>{item}</li>
                    ))}
                  </ul>
                  <h3 className="text-md font-bold text-gray-900 mt-2">Other Person:</h3>
                  <ul className="list-disc list-inside text-gray-700 mb-2">
                    {sc.role_play.other_person.map((item, idx) => (
                      <li key={idx}>{item}</li>
                    ))}
                  </ul>
                  <h3 className="text-md font-bold text-gray-900 mt-2">Things to be Pitched:</h3>
                  <ul className="list-disc list-inside text-gray-700 mb-2">
                    {sc.things_to_be_pitched.map((item, idx) => (
                      <li key={idx}>{item}</li>
                    ))}
                  </ul>
                  <h3 className="text-md font-bold text-gray-900 mt-2">References:</h3>
                  <ul className="list-disc list-inside text-gray-700 mb-2">
                    {sc.references.map((item, idx) => (
                      <li key={idx}><a href={item} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">{item}</a></li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="bg-white rounded-lg shadow-sm min-h-[300px] flex flex-col">
          <div className="flex-1 p-4 space-y-4 overflow-y-auto">
            {messages.length > 0 ? (
              messages.map((message, index) => <ChatMessage key={index} message={message} />)
            ) : (
              <p className="text-gray-500"></p>
            )}
          </div>

          <AudioControls
            audioState={audioState}
            onStartCall={toggleConversation}
            onEndCall={toggleConversation}
          />
        </div>

        {isFeedbackModalOpen && feedbackData && (
        <div className="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
          <div className="bg-white rounded-lg p-6 w-11/12 md:w-3/4 lg:w-2/3 xl:w-1/2 max-h-[90vh] overflow-y-auto"> {/* Adjust modal width and height */}
            <h2 className="text-lg font-semibold text-blue-800 mb-4">Feedback</h2>
            <div className="text-blue-600 whitespace-pre-wrap text-sm">
              <p><strong>Feedback:</strong> {feedbackData.feedback}</p>
              <p><strong>Score:</strong> {feedbackData.score}</p>
              <p><strong>Missed Points to Pitch:</strong> {feedbackData.missed_to_pitch.join(", ")}</p>
              <p><strong>What Went Well:</strong> {feedbackData.what_went_well.join(", ")}</p>
              <p><strong>What Can Improve:</strong> {feedbackData.what_can_improve.join(", ")}</p>
              <p><strong>Next Steps:</strong> {feedbackData.next_steps.join(", ")}</p>
              <p><strong>Suggestions:</strong> {feedbackData.suggestions.join(", ")}</p>
              <p><strong>Comments:</strong> {feedbackData.comments}</p>
            </div>
            <button
              onClick={closeModal}
              className="mt-4 p-2 bg-blue-500 text-white rounded-lg w-full hover:bg-blue-600 transition">
              Close
            </button>
          </div>
        </div>
      )}

        {isLoadingFeedback && (
          <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <h2 className="text-lg font-semibold text-yellow-800">Fetching feedback...</h2>
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default RolePlaySession;