import { useNavigate } from 'react-router-dom'
import { Building2, BarChart2, FileSearch } from 'lucide-react'

const EvaluationOptions = () => {
  const navigate = useNavigate()

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-8">Choose Evaluation Type</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Evaluation by Company */}
        <div 
          onClick={() => navigate('/evaluation-form')}
          className="bg-white p-6 rounded-lg shadow-lg cursor-pointer hover:shadow-xl transition-shadow"
        >
          <div className="flex items-center justify-center mb-4">
            <div className="bg-blue-100 p-3 rounded-full">
              <Building2 className="w-6 h-6 text-blue-600" />
            </div>
          </div>
          <h2 className="text-xl font-bold mb-3 text-center text-gray-800">
            Evaluation by Company
          </h2>
          <p className="text-gray-600 text-sm text-center">
            Analyze conversations for a specific company within a date range
          </p>
        </div>

        {/* General Evaluation with Metrics */}
        <div 
          onClick={() => navigate('/evaluation-metrics')}
          className="bg-white p-6 rounded-lg shadow-lg cursor-pointer hover:shadow-xl transition-shadow"
        >
          <div className="flex items-center justify-center mb-4">
            <div className="bg-green-100 p-3 rounded-full">
              <BarChart2 className="w-6 h-6 text-green-600" />
            </div>
          </div>
          <h2 className="text-xl font-bold mb-3 text-center text-gray-800">
            General Evaluation
          </h2>
          <p className="text-gray-600 text-sm text-center">
            Analyze overall metrics and performance indicators
          </p>
        </div>

        {/* Extract Important Points */}
        <div 
          onClick={() => navigate('/evaluation-extract')}
          className="bg-white p-6 rounded-lg shadow-lg cursor-pointer hover:shadow-xl transition-shadow"
        >
          <div className="flex items-center justify-center mb-4">
            <div className="bg-purple-100 p-3 rounded-full">
              <FileSearch className="w-6 h-6 text-purple-600" />
            </div>
          </div>
          <h2 className="text-xl font-bold mb-3 text-center text-gray-800">
            Extract Important Points
          </h2>
          <p className="text-gray-600 text-sm text-center">
            Extract and analyze key points from conversations
          </p>
        </div>
      </div>
    </div>
  )
}

export default EvaluationOptions