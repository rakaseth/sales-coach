import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-hot-toast'

const EvaluationForm = () => {
  const navigate = useNavigate()
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    company_name: '',
    from_date: '',
    to_date: ''
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    const gongCredentials = localStorage.getItem('gongCredentials')
    if (!gongCredentials) {
      toast.error('Please configure Gong credentials in Settings first')
      navigate('/settings')
      return
    }

    //const { accessKey, secretKey } = JSON.parse(gongCredentials)

    try {
      const response = await fetch('http://localhost:8002/api/evaluate/evaluate-gong-call-by-company', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          company_name: String(formData.company_name),
          from_date: String(formData.from_date), // Format: yyyy-mm-dd
          to_date: String(formData.to_date)      // Format: yyyy-mm-dd
        })
      })

      if (!response.ok) throw new Error('Evaluation failed')

      const data = await response.json()
      localStorage.setItem('evaluationResults', JSON.stringify(data))
      navigate('/evaluation-results')
    } catch (error) {
      toast.error('Failed to fetch evaluation results')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Evaluation Details</h1>
      <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded-lg shadow">
        <div>
          <label className="block text-sm font-medium mb-1">Company Name</label>
          <input
            type="text"
            value={formData.company_name}
            onChange={(e) => setFormData(prev => ({ ...prev, company_name: e.target.value }))}
            className="w-full p-2 border rounded-lg"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Start Date</label>
          <input
            type="date"
            value={formData.from_date}
            onChange={(e) => setFormData(prev => ({ ...prev, from_date: e.target.value }))}
            className="w-full p-2 border rounded-lg"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">End Date</label>
          <input
            type="date"
            value={formData.to_date}
            onChange={(e) => setFormData(prev => ({ ...prev, to_date: e.target.value }))}
            className="w-full p-2 border rounded-lg"
            required
          />
        </div>
        <button
          type="submit"
          disabled={loading}
          className="w-full bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 disabled:bg-blue-300"
        >
          {loading ? 'Processing...' : 'Run Evaluation'}
        </button>
      </form>
    </div>
  )
}

export default EvaluationForm