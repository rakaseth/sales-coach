import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Users, BarChart2, CheckCircle, Clock, X, AlertCircle, Target, Info } from 'lucide-react'

interface User {
  name: string
  email: string
}

interface MetricItem {
  metric: string
  rating: number
  explanation: string
  Metric: string
  Rating: number
  Explanation: string
  'Example 2'?: string
}

interface Evaluation {
  internal_user: User[]
  external_user: User[]
  overall_call_outcome: string
  MEDDPICC: MetricItem[]
  INTERNAL_METRICS: MetricItem[]
  CHALLENGER_EVALUATION: MetricItem[]
  summary?: string
}

interface Result {
  call_id: string
  evaluation: Evaluation
  event_date?: string
  call_duration?: number
}

const EvaluationMetricsResults = () => {
  const navigate = useNavigate()
  const [results, setResults] = useState<Result[]>([])
  const [selectedCall, setSelectedCall] = useState<Result | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState<'meddpicc' | 'internal' | 'challenger'>('meddpicc')
  const [info, setInfo] = useState<string | null>(null)

  useEffect(() => {
    const savedResults = localStorage.getItem('evaluationResults')
    if (!savedResults) {
      navigate('/evaluation-metrics')
      return
    }
    try {
      const parsedResults = JSON.parse(savedResults)
      const validResults = Array.isArray(parsedResults) 
        ? parsedResults.filter(isValidResult)
        : isValidResult(parsedResults) 
          ? [parsedResults] 
          : []

      if (validResults.length === 0) {
        setError('No valid evaluation results found.')
        return
      }
      setResults(validResults)
    } catch (error) {
      console.error('Error parsing results:', error)
      setError('Failed to parse evaluation results. Please try again.')
      navigate('/evaluation-metrics')
    }
  }, [navigate])

  const isValidResult = (result: any): result is Result => {
    return result && 
          typeof result.call_id === 'string' && 
          result.evaluation && 
          Array.isArray(result.evaluation.internal_user) &&
          Array.isArray(result.evaluation.external_user) &&
          Array.isArray(result.evaluation.MEDDPICC) &&
          Array.isArray(result.evaluation.INTERNAL_METRICS) &&
          Array.isArray(result.evaluation?.CHALLENGER_EVALUATION??[])
  }

  const formatDuration = (seconds: number = 0) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes}m ${remainingSeconds}s`
  }

  const formatDate = (dateString: string = '') => {
    try {
      return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      })
    } catch {
      return 'Invalid Date'
    }
  }

  const renderScoreBar = (score: number) => {
    const width = `${(score / 5) * 100}%`
    const getColor = (score: number) => {
      if (score >= 4) return 'bg-green-500'
      if (score >= 3) return 'bg-yellow-500'
      return 'bg-red-500'
    }

    return (
      <div className="w-full bg-gray-200 rounded-full h-2">
        <div
          className={`h-full rounded-full ${getColor(score)}`}
          style={{ width }}
        />
      </div>
    )
  }

  const renderMetrics = (metrics: MetricItem[] = []) => {
    return metrics.map((item, idx) => (
      <div key={idx} className="mb-4 p-4 bg-gray-50 rounded-lg">
        <div className="flex justify-between items-center mb-1">
          <span className="font-medium">{item.metric ?? item.Metric }</span>
          <span className="font-semibold">{item.rating ?? item.Rating }/5</span>
        </div>
        {renderScoreBar(item.rating ?? item.Rating )}
        <div className="mt-2 space-y-2">
          <p className="text-sm text-gray-600">{item.explanation ?? item.Explanation }</p>
          {item['Example 2'] && (
            <p className="text-sm text-gray-600 mt-1">
              <span className="font-medium">Additional Example: </span>
              {item['Example 2']}
            </p>
          )}
        </div>
      </div>
    ))
  }

  const fetchInfo = async () => {
    const meddpiccDescription = "MEDDPICC is an acronym for the eight steps in this sales qualification methodology:\n\n" +
      "Metrics \n" +
      "Economic buyer\n" +
      "Decision criteria\n" +
      "Decision process\n" +
      "Paper process\n" +
      "Implication of pain\n" +
      "Champion\n" +
      "Competition\n\n" +
      "An iteration of the MEDDIC sales process, MEDDPICC adds two more steps to the equation: Decision process and Competition.";
    
    setInfo(meddpiccDescription);
  }

  if (error) {
    return (
      <div className="text-center py-10 text-red-600">
        <p>{error}</p>
        <button 
          onClick={() => navigate('/evaluation-metrics')} 
          className="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
        >
          Go Back
        </button>
      </div>
    )
  }

  if (!results.length) return (
    <div className="text-center py-10">
      <p className="text-gray-600">No evaluation results available.</p>
    </div>
  )

  return (
    <>
      <div className="space-y-6">
        <h1 className="text-2xl font-bold mb-6">Evaluation Analysis</h1>
        
        <div className="grid gap-4">
          {results.map((result, index) => (
            <div 
              key={result.call_id || index} 
              className="bg-white shadow rounded-lg p-4 hover:shadow-lg transition-shadow cursor-pointer"
              onClick={() => setSelectedCall(result)}
            >
              <div className="flex justify-between items-start">
                <div className="space-y-2">
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <Clock className="w-4 h-4" />
                    <span>{formatDate(result.event_date)}</span>
                    <span className="text-gray-400">|</span>
                    <span>{formatDuration(result.call_duration)}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Users className="w-4 h-4 text-blue-500" />
                    <span className="font-medium">
                      {result.evaluation?.internal_user?.[0]?.name || 'Unknown'} + 
                      {(result.evaluation?.internal_user?.length || 1) - 1} others
                    </span>
                  </div>
                </div>
                <button
                  className="text-blue-500 hover:text-blue-600 text-sm font-medium"
                  onClick={(e) => {
                    e.stopPropagation()
                    setSelectedCall(result)
                  }}
                >
                  Show More
                </button>
              </div>
              {result.evaluation?.summary && (
                <p className="text-sm text-gray-700 mt-3 line-clamp-2">
                  {result.evaluation.summary}
                </p>
              )}
            </div>
          ))}
        </div>
      </div>

      {selectedCall && (
        <div className="fixed inset-0 bg-gray-900/50 z-50 overflow-y-auto">
          <div className="min-h-screen px-4 py-8">
            <div className="relative max-w-4xl mx-auto bg-white rounded-xl shadow-2xl">
              <button
                onClick={() => setSelectedCall(null)}
                className="absolute right-4 top-4 text-gray-400 hover:text-gray-600"
              >
                <X className="w-6 h-6" />
              </button>

              <div className="p-6 space-y-6">
                <div className="border-b pb-4">
                  <div className="flex items-center justify-between mb-2">
                    <h2 className="text-xl font-bold">Call Details</h2>
                    <span className="text-sm text-gray-500">
                      {formatDate(selectedCall.event_date)}
                    </span>
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <Clock className="w-4 h-4 mr-2" />
                    <span>{formatDuration(selectedCall.call_duration)}</span>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                      <Users className="w-5 h-5 text-blue-500" />
                      Internal Participants
                    </h3>
                    <div className="space-y-2">
                      {selectedCall.evaluation?.internal_user?.map((user, idx) => (
                        <div key={idx} className="text-sm">
                          <p className="font-medium">{user.name}</p>
                          <p className="text-gray-600">{user.email}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                      <Users className="w-5 h-5 text-green-500" />
                      External Participants
                    </h3>
                    <div className="space-y-2">
                      {selectedCall.evaluation?.external_user?.map((user, idx) => (
                        <div key={idx} className="text-sm">
                          <p className="font-medium">{user.name}</p>
                          <p className="text-gray-600">{user.email}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="mt-4">
                  <div className="flex space-x-4">
                    <button 
                      className={`py-2 px-4 rounded ${activeTab === 'meddpicc' ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}
                      onClick={() => setActiveTab('meddpicc')}
                    >
                      MEDDPICC Analysis
                      <Info className="inline w-4 h-4 ml-1 cursor-pointer" 
                        onMouseEnter={fetchInfo} 
                        onMouseLeave={() => setInfo(null)} 
                      />
                    </button>
                    <button 
                      className={`py-2 px-4 rounded ${activeTab === 'internal' ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}
                      onClick={() => setActiveTab('internal')}
                    >
                      Internal Metrics
                    </button>
                    <button 
                      className={`py-2 px-4 rounded ${activeTab === 'challenger' ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}
                      onClick={() => setActiveTab('challenger')}
                    >
                      Challenger Evaluation
                    </button>
                  </div>

                  <div className="mt-4">
                    {activeTab === 'meddpicc' && (
                      <div className="grid gap-4">
                        {renderMetrics(selectedCall.evaluation?.MEDDPICC)}
                        {info && <p className="text-sm text-gray-600 mt-2">{info}</p>}
                      </div>
                    )}
                    {activeTab === 'internal' && (
                      <div className="grid gap-4">
                        {renderMetrics(selectedCall.evaluation?.INTERNAL_METRICS)}
                      </div>
                    )}
                    {activeTab === 'challenger' && (
                      <div className="grid gap-4">
                        {renderMetrics(selectedCall.evaluation?.CHALLENGER_EVALUATION)}
                      </div>
                    )}
                  </div>
                </div>

                <div className="border-t pt-4">
                  <h3 className="text-lg font-semibold mb-2 flex items-center gap-2">
                    <AlertCircle className="w-5 h-5 text-purple-500" />
                    Overall Call Outcome
                  </h3>
                  <p className="text-gray-700">
                    {selectedCall.evaluation?.overall_call_outcome || 'No outcome recorded'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  )
}

export default EvaluationMetricsResults