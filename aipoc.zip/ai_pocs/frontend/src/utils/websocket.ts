import { CallConfig, Message } from '../types';

export class WebSocketClient {
  private ws: WebSocket | null = null;
  private messageHandler: (message: Message) => void;
  private statusHandler: (connected: boolean) => void;
  private errorHandler: (error: string) => void;

  constructor(
    messageHandler: (message: Message) => void,
    statusHandler: (connected: boolean) => void,
    errorHandler: (error: string) => void
  ) {
    this.messageHandler = messageHandler;
    this.statusHandler = statusHandler;
    this.errorHandler = errorHandler;
  }

  connect(config: CallConfig) {
    const baseUrl = config.baseUrl || 'wss://api.retellai.com';
    const url = `${baseUrl}/websocket?apiKey=${config.apiKey}&callId=${config.callId}`;

    try {
      this.ws = new WebSocket(url);

      this.ws.onopen = () => {
        this.statusHandler(true);
      };

      this.ws.onmessage = (event) => {
        const data = JSON.parse(event.data);
        if (data.type === 'transcript') {
          this.messageHandler({
            role: 'user',
            content: data.transcript.text,
          });
        } else if (data.type === 'error') {
          this.errorHandler(data.error);
        }
      };

      this.ws.onclose = () => {
        this.statusHandler(false);
      };

      this.ws.onerror = (error) => {
        this.errorHandler('WebSocket error occurred');
        console.error('WebSocket error:', error);
      };
    } catch (error) {
      this.errorHandler('Failed to connect to WebSocket');
      console.error('Connection error:', error);
    }
  }

  disconnect() {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }

  sendMessage(message: string) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: 'message', message }));
    }
  }
}