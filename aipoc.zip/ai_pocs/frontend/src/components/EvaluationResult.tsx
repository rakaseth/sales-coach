import React from 'react';
import { CallEvaluation } from '../types';

interface Props {
  evaluation: CallEvaluation;
  onClose: () => void;
}

export default function EvaluationResult({ evaluation, onClose }: Props) {
  const formattedFeedback = evaluation.feedback.split('\n').map((line, index) => {
    if (line.startsWith('###')) {
      // Render as header (h3)
      return (
        <h3 key={index} className="text-lg font-bold mb-2">
          {line.replace(/###/g, '').trim()}
        </h3>
      );
    } else if (line.startsWith('**')) {
      // Render as bold text
      return (
        <p key={index} className="font-bold">
          {line.replace(/\*\*/g, '').trim()}
        </p>
      );
    } else {
      // Render normal text
      return <p key={index} className="text-gray-700 whitespace-pre-wrap">{line}</p>;
    }
  });

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-gray-50 z-50">
      <div className="bg-white rounded-none w-full h-full p-6 overflow-y-auto">
        <h2 className="text-2xl font-bold mb-4">Call Evaluation</h2>

        <div className="mb-4">
          {formattedFeedback}
        </div>

        <button
          onClick={onClose}
          className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          Close
        </button>
      </div>
    </div>
  );
}