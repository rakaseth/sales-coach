import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import LandingPage from './pages/LandingPage';
import RolePlaySetup from './pages/RolePlaySetup';
import RolePlaySession from './pages/RolePlaySession';
import FeedbackPage from './pages/FeedbackPage';
import CoachingSession from './pages/CoachingSession';
import EvaluationPage from './pages/EvaluationPage';
import KnowledgeBaseUpload from './pages/KnowledgeBaseUpload';
import Settings from './pages/Settings'; // Corrected import casing
import EvaluationForm from './pages/EvaluationForm';
import EvaluationResults from './pages/EvaluationResults';
import EvaluationOptions from './pages/EvaluationOptions';
import EvaluationMetrics from './pages/EvaluationMetrics';
import ExtractPoints from './pages/ExtractPoints';
import EvaluationMetricsResults from './pages/EvaluationMetricsResults';
import PreCallPreparation  from './pages/PreCallPreparation';

function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 flex">
        <aside className="w-64 bg-white shadow-md p-4">
          <h2 className="text-lg font-semibold mb-4">Menu</h2>
          <ul>
            <li className="mb-2">
              <Link to="/" className="text-blue-600 hover:underline">Home</Link>
            </li>
            <li className="mb-2">
              <Link to="/settings" className="text-blue-600 hover:underline">Settings</Link> {/* Updated link to point to settings */}
            </li>
          </ul>
        </aside>
        <main className="flex-1 p-4">
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/role-play/setup" element={<RolePlaySetup />} />
            <Route path="/role-play/session" element={<RolePlaySession />} />
            <Route path="/role-play/feedback" element={<FeedbackPage />} />
            <Route path="/coaching" element={<CoachingSession />} />
            <Route path="/evaluate" element={<EvaluationPage />} />
            <Route path="/upload" element={<KnowledgeBaseUpload />} />
            <Route path="/settings" element={<Settings />} /> {/* Added route for settings */}
            <Route path="/evaluation-form" element={<EvaluationForm />} /> {/* Added route for Evaluation Form */}
            <Route path="/evaluation-results" element={<EvaluationResults />} /> {/* Added route for Evaluation Results */}
            <Route path="evaluation-options" element={<EvaluationOptions />} />
            <Route path="/precall_helper" element={<PreCallPreparation />} />
            <Route path="evaluation-form" element={<EvaluationForm />} />
            <Route path="evaluation-metrics" element={<EvaluationMetrics />} />
            <Route path="evaluation-extract" element={<ExtractPoints />} />
            <Route path="/evaluation-results-metrics" element={<EvaluationMetricsResults />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}

export default App;