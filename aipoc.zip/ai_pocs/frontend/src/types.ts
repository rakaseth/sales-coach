export interface Message {
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}

export interface RolePlayConfig {
  topic: string;
  company: string;
  duration: number;
}

export interface FeedbackData {
  dealSummary: string;
  overallImpression: string[];
  whatWentWell: string[];
  growthOpportunities: string[];
}

export interface AudioState {
  isConnected: boolean;
  isCallActive: boolean;
  error: string | null;
  timeRemaining: number;
}

export interface CallEvaluation {
  feedback: string;
  score?: number;
  suggestions?: string[];
}